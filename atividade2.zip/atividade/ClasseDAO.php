<?php
require_once("util.php");
class ClasseDAO
{
    private $entidades;
    private $caminho = "sistema/dao/";
    function __construct($e)
    {
        if (!is_dir($this->caminho)) {
            mkdir($this->caminho, 0777, true);
        }
        $this->entidades = $e;
        $this->criaClasse();
    }
    function criaClasse()
    {
        $util = new Utils();
        $listaEntidades = array_keys($this->entidades);
        foreach ($listaEntidades as $entidade) {
            $listaAtributos = $this->entidades[$entidade];

            // Monta o corpo do montarObjeto() a partir dos atributos da entidade
            $montarObjeto = "";
            foreach ($listaAtributos as $key => $atributo) {
                $montarObjeto .= "\$obj->set" . ucfirst($key) . "(\$dados['$key']);\n\t\t";
            }
            
            $campoPK = 'id';
            foreach ($listaAtributos as $key => $atributo) {
                if ($atributo['primary']) {
                    $campoPK = $key;
                    break;
                }
            }

            $nomeClasse = ucfirst($entidade);
            $conteudo = <<<CLASS
                <?php
                require_once("../model/{$entidade}.php");
                class {$nomeClasse}DAO
                {
                    private PDO \$conexao;

                    public function __construct(PDO \$conexao)
                    {
                        \$this->conexao = \$conexao;
                    }

                    public function inserir({$nomeClasse} \$objeto): bool
                    {
                        // Implementar
                    }

                    public function alterar({$nomeClasse} \$objeto): bool
                    {
                        // Implementar
                    }

                    public function excluir(int \$id): bool
                    {
                        // Implementar
                    }

                    public function buscarPorId(int \$id): ?{$nomeClasse}
                    {
                        \$sql = "SELECT * FROM {$entidade} WHERE {$campoPK} = :id";
                        \$stmt = \$this->conexao->prepare(\$sql);
                        \$stmt->bindParam(':id', \$id, PDO::PARAM_INT);
                        \$stmt->execute();
 
                        \$dados = \$stmt->fetch(PDO::FETCH_ASSOC);
 
                        if (\$dados === false) {
                            return null;
                        }
 
                        return \$this->montarObjeto(\$dados);
                    }
 


                    public function listar(): array
                    {
                        \$sql = "SELECT * FROM {$entidade}";
                        \$stmt = \$this->conexao->prepare(\$sql);
                        \$stmt->execute();

                        \$lista = [];
                        while (\$dados = \$stmt->fetch(PDO::FETCH_ASSOC)) {
                            \$lista[] = \$this->montarObjeto(\$dados);
                        }

                        return \$lista;
                    }

                    private function montarObjeto(array \$dados): {$nomeClasse}
                    {
                        \$obj = new {$nomeClasse}();
                        {$montarObjeto}
                        return \$obj;
                    }
                }
                CLASS;
            file_put_contents("{$this->caminho}{$entidade}DAO.php", $conteudo);
        }
    }
}