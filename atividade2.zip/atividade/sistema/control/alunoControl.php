<?php
require_once('../model/aluno.php');
require_once('../dao/AlunoDAO.php');
require_once('../model/conexao.php');

class AlunoControl {
   private $obj;
   private $dao;
   private $acao;

   public function __construct() {
       $this->obj = new Aluno();
       $this->dao = new AlunoDAO(Conexao::conectar());
       $this->acao = $_REQUEST["acao"];
       $this->executaAcao();
   }

   public function executaAcao() {
       switch ($this->acao) {
           case 1:
               // inserir
               $this->prepararObjeto();
               $this->dao->inserir($this->obj);
               break;

           case 2:
               // listar (busca apresentada na view em forma de tabela)
               $lista = $this->dao->listar();
               include('../view/resultado_aluno.php');
               break;
            
            case 3 
                // buscar por id (também apresentada na mesma view em forma de tabela)
               $id = (int) $_POST['id'];
               $encontrado = $this->dao->buscarPorId($id);
               $lista = ($encontrado !== null) ? [$encontrado] : [];
               include('../view/resultado_aluno.php');
               break;

       }
   }

   public function prepararObjeto() {
      $this->obj->setNome($_POST["nome"]);
	$this->obj->setNascimento($_POST["nascimento"]);
	$this->obj->setCurso($_POST["curso"]);
	
   }
}
new AlunoControl;