<?php
class Conexao{
public static function conectar():PDO{
 try{
 $host="localhost";
 $banco="db_fwk";
 $usuario="root";
 $senha="bancodedados";
 $pdo = new PDO("mysql:host=localhost;dbname=db_fwk;charset=utf8", $usuario, $senha);
 return $pdo;

 }catch(PDOException $e){
 echo $e->getMessage();
 }
 }
}
 ?>