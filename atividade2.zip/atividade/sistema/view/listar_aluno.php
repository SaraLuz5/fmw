<html>
    <head>
        <title>Listagem</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body>
    <div class="container mt-5">
    <h2 class="mb-4">Listagem de aluno</h2>
    <form action="../control/alunoControl.php" method="POST">
    <input type="hidden" name="acao" value="2">
      <button type="submit" class="btn btn-primary">Listar</button>
    </form>
     <a href="buscarId_aluno.php" class="btn btn-link mt-3">Buscar por ID</a>
    </div>
    </body>
</html>