<html>
    <head>
        <title>Resultado da Busca</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body>
    <div class="container mt-5">
    <h2 class="mb-4">Resultado da Busca</h2>
    <table class="table table-striped table-bordered">
        <thead>
            <tr>
                <th>id</th>
						<th>nome</th>
						<th>titulacao</th>
						
            </tr>
        </thead>
        <tbody>
            <?php foreach ($lista as $item): ?>
            <tr>
                <td><?= $item->getId() ?></td>
						<td><?= $item->getNome() ?></td>
						<td><?= $item->getTitulacao() ?></td>
						
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <a href="form_professor.php" class="btn btn-secondary">Voltar</a>
    </div>
    </body>
</html>