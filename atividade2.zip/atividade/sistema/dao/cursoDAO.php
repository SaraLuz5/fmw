<?php
require_once("../model/curso.php");
class CursoDAO
{
    private PDO $conexao;

    public function __construct(PDO $conexao)
    {
        $this->conexao = $conexao;
    }

    public function inserir(Curso $objeto): bool
    {
        // Implementar
    }

    public function alterar(Curso $objeto): bool
    {
        // Implementar
    }

    public function excluir(int $id): bool
    {
        // Implementar
    }

    public function buscarPorId(int $id): ?Curso
    {
        $sql = "SELECT * FROM curso WHERE id = :id";
        $stmt = $this->conexao->prepare($sql);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();

        $dados = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($dados === false) {
            return null;
        }

        return $this->montarObjeto($dados);
    }



    public function listar(): array
    {
        $sql = "SELECT * FROM curso";
        $stmt = $this->conexao->prepare($sql);
        $stmt->execute();

        $lista = [];
        while ($dados = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $lista[] = $this->montarObjeto($dados);
        }

        return $lista;
    }

    private function montarObjeto(array $dados): Curso
    {
        $obj = new Curso();
        $obj->setId($dados['id']);
		$obj->setNome($dados['nome']);
		$obj->setDuracao($dados['duracao']);
		
        return $obj;
    }
}