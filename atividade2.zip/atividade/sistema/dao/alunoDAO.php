<?php
require_once("../model/aluno.php");
class AlunoDAO
{
    private PDO $conexao;

    public function __construct(PDO $conexao)
    {
        $this->conexao = $conexao;
    }

    public function inserir(Aluno $objeto): bool
    {
        // Implementar
    }

    public function alterar(Aluno $objeto): bool
    {
        // Implementar
    }

    public function excluir(int $id): bool
    {
        // Implementar
    }

    public function buscarPorId(int $id): ?Aluno
    {
        $sql = "SELECT * FROM aluno WHERE id = :id";
        $stmt = $this->conexao->prepare($sql);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();

        $dados = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($dados === false) {
            return null;
        }

        return $this->montarObjeto($dados);
    }



    public function listar(): array
    {
        $sql = "SELECT * FROM aluno";
        $stmt = $this->conexao->prepare($sql);
        $stmt->execute();

        $lista = [];
        while ($dados = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $lista[] = $this->montarObjeto($dados);
        }

        return $lista;
    }

    private function montarObjeto(array $dados): Aluno
    {
        $obj = new Aluno();
        $obj->setId($dados['id']);
		$obj->setNome($dados['nome']);
		$obj->setNascimento($dados['nascimento']);
		$obj->setCurso($dados['curso']);
		
        return $obj;
    }
}