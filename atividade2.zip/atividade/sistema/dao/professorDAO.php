<?php
require_once("../model/professor.php");
class ProfessorDAO
{
    private PDO $conexao;

    public function __construct(PDO $conexao)
    {
        $this->conexao = $conexao;
    }

    public function inserir(Professor $objeto): bool
    {
        // Implementar
    }

    public function alterar(Professor $objeto): bool
    {
        // Implementar
    }

    public function excluir(int $id): bool
    {
        // Implementar
    }

    public function buscarPorId(int $id): ?Professor
    {
        $sql = "SELECT * FROM professor WHERE id = :id";
        $stmt = $this->conexao->prepare($sql);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();

        $dados = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($dados === false) {
            return null;
        }

        return $this->montarObjeto($dados);
    }



    public function listar(): array
    {
        $sql = "SELECT * FROM professor";
        $stmt = $this->conexao->prepare($sql);
        $stmt->execute();

        $lista = [];
        while ($dados = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $lista[] = $this->montarObjeto($dados);
        }

        return $lista;
    }

    private function montarObjeto(array $dados): Professor
    {
        $obj = new Professor();
        $obj->setId($dados['id']);
		$obj->setNome($dados['nome']);
		$obj->setTitulacao($dados['titulacao']);
		
        return $obj;
    }
}