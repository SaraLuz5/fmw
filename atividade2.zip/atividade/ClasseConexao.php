<?php
class ClasseConexao
{
 
    private $caminho = "sistema/model/";
    public function __construct($banco, $host, $sql = null)
    {
        $this->criarClasse($banco, $host);
        if ($sql !== null) {
            $this->executarSQLNoBanco($banco, $host, $sql);
        }
    }
 
    public function executarSQLNoBanco($banco, $host, $sql)
    {
        try {
            $usuario = "root";
            $senha = "bancodedados";
 
            $pdo = new PDO("mysql:host={$host};charset=utf8", $usuario, $senha);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$banco}` CHARACTER SET utf8");
            $pdo->exec("USE `{$banco}`");
 
            // Executa todos os comandos do arquivo .sql (CREATE TABLE, ALTER TABLE, etc.)
            $pdo->exec($sql);
        } catch (PDOException $e) {
            echo "Erro ao criar a tabela no banco de dados: " . $e->getMessage();
        }
    }
    public function criarClasse($banco, $host)
    {
        $conteudo = <<<CLASS
      <?php
      class Conexao{
      public static function conectar():PDO{
       try{
       \$host="$host";
       \$banco="$banco";
       \$usuario="root";
       \$senha="bancodedados";
       \$pdo = new PDO("mysql:host={$host};dbname={$banco};charset=utf8", \$usuario, \$senha);
       return \$pdo;
 
       }catch(PDOException \$e){
       echo \$e->getMessage();
       }
       }
      }
       ?>
      CLASS;
 
      file_put_contents("{$this->caminho}conexao.php", $conteudo);
    }
}
