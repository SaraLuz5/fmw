<?php
// compactar.php - compacta a pasta "sistema" gerada pelo framework e força o download

$diretorio = realpath(__DIR__ . '/sistema');   // pasta gerada pelo LeitorSQL.php
$nomeZip   = 'sistema.zip';                    // nome que o usuário vai receber

if ($diretorio === false || !is_dir($diretorio)) {
    die("Pasta 'sistema' não encontrada. Envie um arquivo SQL primeiro.");
}
if (!class_exists('ZipArchive')) {
    die("A extensão php-zip não está ativada no servidor.");
}

// ZIP temporário fora da pasta do projeto (evita entrar no próprio zip / problemas de permissão)
$caminhoZip = tempnam(sys_get_temp_dir(), 'zip');

$zip = new ZipArchive();
if ($zip->open($caminhoZip, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
    die("Erro ao criar o arquivo compactado.");
}

$arquivos = new RecursiveIteratorIterator(
    new RecursiveDirectoryIterator($diretorio, FilesystemIterator::SKIP_DOTS),
    RecursiveIteratorIterator::LEAVES_ONLY
);

foreach ($arquivos as $arquivo) {
    if ($arquivo->isDir()) continue;
    $completo = $arquivo->getRealPath();
    // caminho relativo com "/" (padrão do ZIP, mesmo no Windows), dentro de uma pasta "sistema/"
    $relativo = 'sistema/' . str_replace('\\', '/', substr($completo, strlen($diretorio) + 1));
    $zip->addFile($completo, $relativo);
}
$zip->close();

// Envia o download
while (ob_get_level()) { ob_end_clean(); }
header('Content-Type: application/zip');
header('Content-Disposition: attachment; filename="' . $nomeZip . '"');
header('Content-Length: ' . filesize($caminhoZip));
header('Pragma: no-cache');
header('Expires: 0');
readfile($caminhoZip);
unlink($caminhoZip);   // remove o temporário
exit;
