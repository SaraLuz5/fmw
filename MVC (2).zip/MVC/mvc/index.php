<?php
if(isset($_GET["erro"])){
    switch ($_GET["erro"]){
        case 0:
            echo "<div class='erro'>Apenas arquivos SQL são permitidos.</div>";
            break;
        case 1:
            echo "<div class='erro'>Não foi possível ler a estrutura do arquivo enviado.</div>";
            break;
        case 2:
            $msg = htmlspecialchars($_GET["msg"] ?? "Erro desconhecido.");
            echo "<div class='erro'>Não foi possível importar o banco automaticamente.<br><small>{$msg}</small></div>";
            break;
    }
}
if(isset($_GET["sucesso"])){
    echo "<div class='sucesso'>
        Sistema criado com sucesso!<br>
        <a href='compactar.php'>Baixar o sistema compactado (.zip)</a>
        &nbsp;|&nbsp;
        <a href='sistema/index.php' target='_blank'>Abrir o sistema</a>
    </div>";
}
?>
<!doctype html>
<html lang="en">
<head>
    <title>Framework MVC</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<h1> Framework MVC</h1> <h2>Converta seu arquivo SQL em um sistema MVC completo</h2>
<form action="LeitorSQL.php" method="post" enctype="multipart/form-data">
    <label for="arquivo">Envie seu arquivo SQL</label>
    <input type="file" name="arquivo" required><br>
    <button type="submit">Enviar</button>

</form>
</body>
</html>