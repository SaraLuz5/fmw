<?php
$diretorioParaCompactar = realpath(__DIR__ . '/sistema');
$nomeZip = 'sistema.zip';

if ($diretorioParaCompactar === false || !is_dir($diretorioParaCompactar)) {
    http_response_code(404);
    exit('O sistema ainda não foi criado. Envie um arquivo SQL primeiro.');
}

if (file_exists(__DIR__ . '/' . $nomeZip)) {
    unlink(__DIR__ . '/' . $nomeZip);
}

$zip = new ZipArchive();
$caminhoZip = __DIR__ . '/' . $nomeZip;

if ($zip->open($caminhoZip, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
    http_response_code(500);
    exit('Erro ao criar o arquivo compactado.');
}

$arquivos = new RecursiveIteratorIterator(
    new RecursiveDirectoryIterator($diretorioParaCompactar, FilesystemIterator::SKIP_DOTS),
    RecursiveIteratorIterator::LEAVES_ONLY
);

foreach ($arquivos as $arquivo) {
    if (!$arquivo->isFile()) {
        continue;
    }

    $caminhoCompleto = $arquivo->getRealPath();
    $caminhoRelativo = substr($caminhoCompleto, strlen($diretorioParaCompactar) + 1);

    $zip->addFile($caminhoCompleto, 'sistema/' . $caminhoRelativo);
}

$zip->close();

if (file_exists($caminhoZip)) {
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="' . basename($nomeZip) . '"');
    header('Content-Length: ' . filesize($caminhoZip));
    header('Pragma: no-cache');
    header('Expires: 0');

    if (ob_get_level()) {
        ob_clean();
    }
    flush();

    readfile($caminhoZip);

    unlink($caminhoZip);
    exit;
}

http_response_code(500);
echo 'Erro ao criar o arquivo compactado.';
