CREATE DATABASE IF NOT EXISTS biblioteca DEFAULT CHARACTER SET utf8mb4;
USE biblioteca;

CREATE TABLE autor (
  codigo INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(80) NOT NULL,
  pais CHAR(2) DEFAULT NULL,
  nascimento DATE
);

CREATE TABLE IF NOT EXISTS `livro` (
  codigo INT NOT NULL AUTO_INCREMENT,
  titulo VARCHAR(150) NOT NULL,
  paginas SMALLINT DEFAULT 0,
  preco DECIMAL(8,2) DEFAULT 0.00,
  resumo TEXT,
  disponivel TINYINT(1) DEFAULT 1,
  PRIMARY KEY (codigo)
);

CREATE TABLE emprestimo (
  id INT NOT NULL AUTO_INCREMENT,
  leitor VARCHAR(80) NOT NULL,
  retirada DATE NOT NULL,
  devolucao DATE,
  situacao ENUM('aberto','devolvido','atrasado') DEFAULT 'aberto',
  multa DECIMAL(6,2) DEFAULT 0.00,
  codigo_livro INT,
  PRIMARY KEY (id)
);

ALTER TABLE emprestimo
  ADD CONSTRAINT fk_emprestimo_livro FOREIGN KEY (codigo_livro) REFERENCES livro (codigo);

INSERT INTO autor (nome, pais, nascimento) VALUES
('Machado de Assis','BR','1839-06-01'),
('Clarice Lispector','BR','1920-12-10');

INSERT INTO livro (titulo, paginas, preco, resumo) VALUES
('Dom Casmurro',256,39.90,'Bentinho, Capitu e a dúvida.'),
('A hora da estrela',96,34.50,'Macabéa em São Paulo.');
