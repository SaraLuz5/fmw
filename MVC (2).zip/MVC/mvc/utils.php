<?php
class Utils{
    function converterTipoPHP(string $tipoSQL): string
    {
        $tipoSQL = strtolower($tipoSQL);
        $tipoSQL = preg_replace('/\(.*\)/', '', $tipoSQL);
        $tipoSQL = trim(preg_replace('/\s+(unsigned|zerofill)/', '', $tipoSQL));
        return match($tipoSQL){
            'int', 'bigint', 'smallint', 'tinyint', 'mediumint' => 'int',
            'varchar', 'char', 'text', 'longtext', 'mediumtext', 'enum', 'set' => 'string',
            'decimal', 'float', 'double' => 'float',
            'date', 'datetime', 'timestamp' => 'string',
            'bool', 'boolean' => 'bool',
            default => 'mixed'
        };
    }
    function converterTipoPHPForm(string $tipoSQL): string
    {
        $tipoSQL = strtolower($tipoSQL);
        $tipoSQL = preg_replace('/\(.*\)/', '', $tipoSQL);
        $tipoSQL = trim(preg_replace('/\s+(unsigned|zerofill)/', '', $tipoSQL));
        return match($tipoSQL){
            'int', 'bigint', 'smallint', 'tinyint', 'mediumint' => 'number',
            'decimal', 'float', 'double' => 'number',
            'date' => 'date',
            'datetime', 'timestamp' => 'datetime-local',
            default => 'text' // varchar, char, text, enum e qualquer tipo nao mapeado
        };
    }
}
