<?php
require_once ("ClassesModel.php");
require_once ("ClassesView.php");
require_once ("ClassesControl.php");
require_once ("ClassesDAO.php");
require_once ("ClassesConexao.php");
class LeitorSQL
{
    private $conteudo;
    private $conteudoOriginal;
    private $tabelas = [];
    private $banco;
    private $host;
    public function receberArquivoSQL($arquivo)
    {
        if (!file_exists($arquivo)) {
            throw new Exception("Arquivo não encontrado.");
        }
        $this->conteudo = file_get_contents($arquivo);
        $this->conteudoOriginal = $this->conteudo;
        $this->processarTabelas();
    }

    private function corpoEntreParenteses(string $texto, int $posAbre): ?string
    {
        $tamanho = strlen($texto);
        $nivel = 0;
        for ($i = $posAbre; $i < $tamanho; $i++) {
            $c = $texto[$i];
            if ($c === "'" || $c === '"' || $c === '`') {
                $fechamento = $c;
                $i++;
                while ($i < $tamanho && $texto[$i] !== $fechamento) {
                    if ($texto[$i] === '\\') { $i++; }
                    $i++;
                }
                continue;
            }
            if ($c === '(') { $nivel++; }
            if ($c === ')') {
                $nivel--;
                if ($nivel === 0) {
                    return substr($texto, $posAbre + 1, $i - $posAbre - 1);
                }
            }
        }
        return null;
    }

    private function processarTabelas()
    {
        preg_match(
            '/--\s*Host:\s*(\S+)/',
            $this->conteudo,
            $this->host
        );
        preg_match(
            '/Banco de dados:\s*`([^`]+)`|Database:\s*([A-Za-z0-9_$]+)|CREATE DATABASE(?:\s+IF NOT EXISTS)?\s+`?([A-Za-z0-9_$]+)`?|USE\s+`?([A-Za-z0-9_$]+)`?\s*;/i',
            $this->conteudo,
            $this->banco
        );
        $this->conteudo = preg_replace('#/\*![0-9]*\s.*?\*/#s', ' ', $this->conteudo);

        preg_match_all(
            '/CREATE TABLE\s+(?:IF NOT EXISTS\s+)?`?([A-Za-z0-9_$]+)`?\s*\(/i',
            $this->conteudo,
            $inicios,
            PREG_SET_ORDER | PREG_OFFSET_CAPTURE
        );

        foreach ($inicios as $inicio) {
            $nomeTabela = $inicio[1][0];
            $posAbre    = $inicio[0][1] + strlen($inicio[0][0]) - 1; // posição do "("
            $camposTexto = $this->corpoEntreParenteses($this->conteudo, $posAbre);
            if ($camposTexto === null) {
                continue;
            }
            $this->tabelas[$nomeTabela] = [];
            $linhas = explode("\n", $camposTexto);

            foreach ($linhas as $linha) {
                $linha = trim($linha, " \t\r\n,");
                if ($linha === '') {
                    continue;
                }
                if (preg_match('/^(PRIMARY\s+KEY|UNIQUE|KEY|INDEX|FULLTEXT|CONSTRAINT|FOREIGN\s+KEY|CHECK)\b/i', $linha)) {
                    continue;
                }
                preg_match('/^`?([A-Za-z0-9_$]+)`?\s+([a-zA-Z0-9(),\' "]+?)(?:\s+NOT\s+NULL|\s+NULL|\s+DEFAULT|\s+AUTO_INCREMENT|\s+PRIMARY\s+KEY|,?$)/i', $linha, $campo);
                $nomeCampo = $campo[1] ?? '';
                $tipoCampo = trim($campo[2] ?? '');
                if ($nomeCampo === '' || $tipoCampo === '') {
                    continue;
                }
                $this->tabelas[$nomeTabela][$nomeCampo] = [
                    'tipo' => $tipoCampo,
                    'primary' => (bool) preg_match('/PRIMARY\s+KEY/i', $linha)
                ];
            }
        }
        preg_match_all(
            '/ALTER TABLE `?([A-Za-z0-9_$]+)`?(.*?)ADD PRIMARY KEY\s*\(`?([A-Za-z0-9_$]+)`?\)/is',
            $this->conteudo,
            $primaryMatches,
            PREG_SET_ORDER
        );
        foreach ($primaryMatches as $match) {
            $tabela = $match[1];
            $campoPK = $match[3];
            if (isset($this->tabelas[$tabela][$campoPK])) {
                $this->tabelas[$tabela][$campoPK]['primary'] = true;
            }
        }
       preg_match_all(
            '/ALTER TABLE `([^`]+)`\s+ADD CONSTRAINT `[^`]+`\s+
            FOREIGN KEY \(`([^`]+)`\)\s+REFERENCES `([^`]+)` \(`([^`]+)`\)/',
            $this->conteudo,
            $estrangeira,
            PREG_SET_ORDER
        );

        foreach ($this->tabelas as $nomeTabela => $campos) {
            $temChave = false;
            foreach ($campos as $dados) {
                if ($dados['primary']) { $temChave = true; break; }
            }
            if (!$temChave && $campos) {
                $primeiraColuna = array_key_first($campos);
                $this->tabelas[$nomeTabela][$primeiraColuna]['primary'] = true;
            }
        }
    }

 function  iniciar()
  {
      $arquivo = $_FILES['arquivo'];
      $arquivo_tmp = $arquivo['tmp_name'];
      $arquivo_size = $arquivo['size'];
      $arquivo_name = explode('.', $arquivo['name']);
      $extensao = strtolower(end($arquivo_name));
      if ($extensao != "sql") {
          header("location: index.php?erro=0");
          exit();
      } else {
          move_uploaded_file($arquivo_tmp, $arquivo["name"]);
          $this->receberArquivoSQL($arquivo["name"]);

          $this->limparPasta('sistema');

          if (!$this->tabelas) {
              header("location: index.php?erro=1");
              exit();
          }

          $banco = '';
          foreach (array_slice((array) $this->banco, 1) as $grupo) {
              if ($grupo !== '') { $banco = $grupo; break; }
          }
          if ($banco === '') {
              $banco = pathinfo($arquivo["name"], PATHINFO_FILENAME);
          }
          $host = $this->host[1] ?? '';
          if (trim($host) === '') {
              $host = 'localhost'; // valor padrão quando o dump não informa o host
          }
          try {
              $this->importarNoBanco($banco, $host);
          } catch (Exception $e) {
              header("location: index.php?erro=2&msg=" . urlencode($e->getMessage()));
              exit();
          }

          new ClassesModel($this->tabelas);
          new ClassesView($this->tabelas, $banco);
          new ClassesControl($this->tabelas);
          new ClassesDAO($this->tabelas);
          new ClassesConexao($banco, $host);

          $zip = $this->compactarSistema();
          header("location: index.php?sucesso=1&zip=" . urlencode($zip));
          exit();
      }
  }
    private function importarNoBanco(string $banco, string $host): void
    {
        try {
            $pdo = new PDO(
                "mysql:host={$host};charset=utf8mb4",
                "root",
                "",
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::MYSQL_ATTR_MULTI_STATEMENTS => true,
                ]
            );
        } catch (PDOException $e) {
            throw new Exception(
                "Não foi possível conectar ao MySQL em \"{$host}\" com o usuário root. "
                . "Verifique se o MySQL está ligado. Detalhe: " . $e->getMessage()
            );
        }

        try {
          $pdo->exec("DROP DATABASE IF EXISTS `{$banco}`");
            $pdo->exec("CREATE DATABASE `{$banco}`");
            $pdo->exec("USE `{$banco}`");
            $pdo->exec($this->conteudoOriginal);
        } catch (PDOException $e) {
            throw new Exception(
                "O banco \"{$banco}\" foi criado, mas houve um erro ao executar o "
                . "arquivo .sql enviado. Detalhe: " . $e->getMessage()
            );
        }
    }
    private function limparPasta(string $pasta): void
    {
        if (!is_dir($pasta)) {
            return;
        }
        $itens = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($pasta, FilesystemIterator::SKIP_DOTS),
            RecursiveIteratorIterator::CHILD_FIRST
        );
        foreach ($itens as $item) {
            $item->isDir() ? rmdir($item->getPathname()) : unlink($item->getPathname());
        }
        rmdir($pasta);
    }
    private function compactarSistema(): string
    {
        $nomeZip = 'sistema.zip';
        if (file_exists($nomeZip)) {
            unlink($nomeZip);
        }

        $zip = new ZipArchive();
        $zip->open($nomeZip, ZipArchive::CREATE | ZipArchive::OVERWRITE);

        $itens = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator('sistema', FilesystemIterator::SKIP_DOTS)
        );
        foreach ($itens as $item) {
            $caminhoRelativo = 'sistema/' . substr($item->getPathname(), strlen('sistema/'));
            $zip->addFile($item->getPathname(), $caminhoRelativo);
        }
        $zip->close();

        return $nomeZip;
    }
}
(new LeitorSQL())->iniciar();
?>