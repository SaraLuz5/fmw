<?php
require_once("utils.php");
class ClassesView
{
    private $entidades;
    private $caminho = "sistema/view/";
    private $banco = "";
    function __construct($e, $banco = "")
    {
        $this->banco = ucfirst($banco);
        if (!is_dir($this->caminho)) {
            mkdir($this->caminho, 0777, true);
        }
        $this->entidades = $e;
        $this->criaFormulario();
        $this->criaLista();
        $this->criarIndex();
    }
    function criaLista()
    {
        $listaEntidades = array_keys($this->entidades);
        foreach ($listaEntidades as $entidade) {
            $listaAtributos = $this->entidades[$entidade];
            $cabecalho = "";
            $dados = "";
            foreach ($listaAtributos as $key => $atributo) {
                if ($atributo["primary"]) $chave = $key;
                $cabecalho .= "<th>$key</th>\n";
                $dados .= "<td><?php echo \$dado['{$key}']?></td>\n";
            }
            $cabecalho .= "<th colspan='2'>Gerenciar</th>\n";
            $p1 = "acao=3";
            $p2 = "id=<?php echo \$dado['{$chave}'] ?>";
            $p3 = "acao=4";
            $dados .= "<td>
            <a href='../control/{$entidade}Control.php?{$p1}&{$p2}'>Excluir</a></td>\n";
            $dados .= "<td><a href='../control/{$entidade}Control.php?{$p3}&{$p2}'>Alterar</a></td>\n";
            $classe = ucfirst($entidade);
            $conteudo = <<<LISTA
                <?php
                ini_set('display_errors',1);
                ini_set('display_startup_erros',1);
                    error_reporting(E_ALL);
                  require_once __DIR__.'/../control/{$entidade}Control.php';
                  \$_REQUEST['acao'] = 2;
                  \$control = new {$classe}Control();
                  \$dados = \$control->executaAcao();
                ?>
                <html>
                    <head>
                        <title>Lista de {$entidade}</title>
                          <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
                          <style>
                            body{ background:#fff5f9; color:#831843; }
                            h2{ color:#9d174d; }
                            a{ color:#be185d; }
                            a:hover{ color:#831843; }
                            .table-dark{ --bs-table-bg:#be185d; --bs-table-border-color:#9d174d; --bs-table-color:#fff; }
                            .table-striped>tbody>tr:nth-of-type(odd)>*{ --bs-table-bg-type:#fdf2f8; }
                            .table>:not(caption)>*>*{ border-color:#fbcfe8; }
                            .btn-primary{ --bs-btn-bg:#db2777; --bs-btn-border-color:#db2777; --bs-btn-hover-bg:#be185d; --bs-btn-hover-border-color:#be185d; --bs-btn-active-bg:#9d174d; --bs-btn-active-border-color:#9d174d; --bs-btn-color:#fff; --bs-btn-hover-color:#fff; }
                            .form-control:focus{ border-color:#f472b6; box-shadow:0 0 0 .25rem rgba(236,72,153,.25); }
                        </style>
                    </head>
                    <body>
                    <div class="container mt-4">
                    <h2 class="mb-3">Lista de {$entidade}</h2>
                    <table class="table table-striped table-bordered align-middle">
                    <thead class="table-dark">
                    <tr> {$cabecalho}</tr>
                    </thead>
                    <tbody>
                     <?php
                        foreach (\$dados as \$dado) {
                      ?>
                    <tr>{$dados}</tr>
                    <?php
                    }
                    ?>
                    </tbody>
                    </table>
                    </div>
                    </body>
                </html>
                LISTA;
            file_put_contents("{$this->caminho}lista_" . $entidade . ".php", $conteudo);
        }
    }
    function criaFormulario()
    {
        $util = new Utils();
        $listaEntidades = array_keys($this->entidades);
        foreach ($listaEntidades as $entidade) {
            $listaAtributos = $this->entidades[$entidade];
            $campos = "";
            $chave = "";
            foreach ($listaAtributos as $key => $atributo) {
                if (!$atributo["primary"]) {
                    $tipoForm = $util->converterTipoPHPForm($atributo["tipo"]);
                    $campos .= "<div class=\"mb-3\">";
                    $campos .= "<label for=\"$key\" class=\"form-label\">$key</label>";
                    $campos .= "<input value='<?php echo (\$alt)?\$obj->get" . ucFirst($key) . "():\"\";?>'  type='" . $tipoForm . "' name='" . $key . "' class=\"form-control\">";
                    $campos .= "</div>\n\t";
                } else {
                    $chave = $key;
                }
            }
            $campoOculto = "<?php if(\$alt): ?>\n\t\t\t<input type=\"hidden\" name=\"$chave\" value=\"<?php echo \$obj->get" . ucfirst($chave) . "();?>\">\n\t\t\t<?php endif; ?>";
            $conteudo = <<<FORM
                <html>
                    <head>
                        <title>Cadastro</title>
                          <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
                          <style>
                            body{ background:#fff5f9; color:#831843; }
                            h2{ color:#9d174d; }
                            a{ color:#be185d; }
                            a:hover{ color:#831843; }
                            .table-dark{ --bs-table-bg:#be185d; --bs-table-border-color:#9d174d; --bs-table-color:#fff; }
                            .table-striped>tbody>tr:nth-of-type(odd)>*{ --bs-table-bg-type:#fdf2f8; }
                            .table>:not(caption)>*>*{ border-color:#fbcfe8; }
                            .btn-primary{ --bs-btn-bg:#db2777; --bs-btn-border-color:#db2777; --bs-btn-hover-bg:#be185d; --bs-btn-hover-border-color:#be185d; --bs-btn-active-bg:#9d174d; --bs-btn-active-border-color:#9d174d; --bs-btn-color:#fff; --bs-btn-hover-color:#fff; }
                            .form-control:focus{ border-color:#f472b6; box-shadow:0 0 0 .25rem rgba(236,72,153,.25); }
                        </style>
                    </head>
                    <body>
                    <?php
                     \$alt=false;
                       if(isset(\$obj))
                       \$alt=true;
                    ?>
                    <div class="container mt-5">
                    <h2 class="mb-4">Cadastro</h2>
                    <form action="../control/{$entidade}Control.php" method="POST">
                    <input type="hidden" name="acao" value="<?php echo (\$alt)?5:1;?>">
                    $campoOculto
                      $campos
                      <button type="submit" class="btn btn-primary">Salvar</button>
                    </form>
                    </body>
                </html>
                FORM;
            file_put_contents("{$this->caminho}form_" . $entidade . ".php", $conteudo);
        }
    }

    function criarIndex()
    {
        $listaEntidades = array_keys($this->entidades);
        $itensMenuCadastro = "";
        $itensMenuRelatorio = "";
        foreach ($listaEntidades as $entidade) {
            $rotulo = ucfirst($entidade);
            $itensMenuCadastro  .= "<li><a class=\"dropdown-item\" href=\"view/form_{$entidade}.php\">{$rotulo}</a></li>\n";
            $itensMenuRelatorio .= "<li><a class=\"dropdown-item\" href=\"view/lista_{$entidade}.php\">{$rotulo}</a></li>\n";
        }
        $conteudo = <<<INDEX
        <!doctype html>
        <html lang="pt-br">
        <head>
        <meta charset="utf-8">
        <title>Painel do sistema</title>
        <base target="principal">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
        <style>
            html, body{ 
                height: 100%; 
                margin: 0; 
            }
            body{ 
                display: flex; 
                flex-direction: column; 
            }
            #conteudo{ 
                flex: 1; 
                padding: 18px; 
                background: #fdf2f8; 
            }
            #conteudo iframe{ 
                width: 100%; 
                height: 100%; 
                border: none; 
                background: #fff; 
            }
        </style>
        </head>
        <body>

            <nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #be185d;">
                <div class="container-fluid">
                    <a class="navbar-brand" href="inicio.php" target="principal">{$this->banco}</a>
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" href="inicio.php" target="principal">Início</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Cadastrar</a>
                            <ul class="dropdown-menu">
                                $itensMenuCadastro
                            </ul>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Listar</a>
                            <ul class="dropdown-menu">
                                $itensMenuRelatorio
                            </ul>
                        </li>
                    </ul>
                </div>
            </nav>

            <div id="conteudo">
                <iframe name="principal" src="inicio.php"></iframe>
            </div>

            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
        </body>
        </html>
        INDEX;
        file_put_contents("sistema/index.php", $conteudo);
        $this->criarInicio($listaEntidades);
    }

    function criarInicio($listaEntidades)
    {
        $cartoes = "";
        foreach ($listaEntidades as $entidade) {
            $rotulo = ucfirst($entidade);
            $totalCampos = count($this->entidades[$entidade]);
            $cartoes .= <<<CARTAO
            <a class="cartao" href="view/lista_{$entidade}.php" target="principal">
                <div class="cartao-texto">
                    <h3>{$rotulo}</h3>
                    <p><?php
                        require_once __DIR__ . "/dao/{$entidade}DAO.php";
                        echo count((new {$rotulo}DAO())->listar());
                    ?> registro(s) · {$totalCampos} coluna(s)</p>
                </div>
            </a>

            CARTAO;
        }

        $conteudo = <<<INICIO
        <!doctype html>
        <html lang="pt-br">
        <head>
        <meta charset="utf-8">
        <title>Início</title>
        <style>
            *{ box-sizing: border-box; }
            body{
                margin: 0;
                padding: 28px;
                font-family: "Segoe UI", Arial, sans-serif;
                background: #fff5f9;
                color: #831843;
            }
            h2{
                margin: 0 0 6px;
                font-size: 1.5rem;
            }
            p.subtitulo{
                margin: 0 0 26px;
                color: #be185d;
            }
            .grade{
                display: grid;
                grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
                gap: 16px;
            }
            .cartao{
                display: flex;
                align-items: center;
                gap: 14px;
                padding: 18px;
                border-radius: 8px;
                background: #fdf2f8;
                border: 1px solid #fbcfe8;
                text-decoration: none;
                color: inherit;
            }
            .cartao:hover{
                border-color: #ec4899;
                box-shadow: 0 4px 12px rgba(236,72,153,.25);
            }
            .cartao-texto h3{
                margin: 0 0 4px;
                font-size: 1.05rem;
            }
            .cartao-texto p{
                margin: 0;
                font-size: .85rem;
                color: #be185d;
            }
        </style>
        </head>
        <body>
            <h2>Bem-vindo!</h2>
            <p class="subtitulo">Escolha uma tabela abaixo para listar, ou use o menu ao lado para cadastrar um novo registro.</p>
            <div class="grade">
                $cartoes
            </div>
        </body>
        </html>
        INICIO;
        file_put_contents("sistema/inicio.php", $conteudo);
    }
}

