<?php
class Autor {
   private ?int $codigo = null;
   private ?string $nome = null;
   private ?string $pais = null;
   private ?string $nascimento = null;

function getCodigo() : ?int{
return $this->codigo;
 }
function setCodigo($arg){
 $this->codigo = ($arg === '' || $arg === null) ? null : $arg;
 }
function getNome() : ?string{
return $this->nome;
 }
function setNome($arg){
 $this->nome = ($arg === '' || $arg === null) ? null : $arg;
 }
function getPais() : ?string{
return $this->pais;
 }
function setPais($arg){
 $this->pais = ($arg === '' || $arg === null) ? null : $arg;
 }
function getNascimento() : ?string{
return $this->nascimento;
 }
function setNascimento($arg){
 $this->nascimento = ($arg === '' || $arg === null) ? null : $arg;
 }

function __toString(){
return  "nome :".$this->nome."<br>".
 "pais :".$this->pais."<br>".
 "nascimento :".$this->nascimento."<br>";
}
}