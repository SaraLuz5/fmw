<?php
class Emprestimo {
   private ?int $id = null;
   private ?string $leitor = null;
   private ?string $retirada = null;
   private ?string $devolucao = null;
   private ?string $situacao = null;
   private ?float $multa = null;
   private ?int $codigo_livro = null;

function getId() : ?int{
return $this->id;
 }
function setId($arg){
 $this->id = ($arg === '' || $arg === null) ? null : $arg;
 }
function getLeitor() : ?string{
return $this->leitor;
 }
function setLeitor($arg){
 $this->leitor = ($arg === '' || $arg === null) ? null : $arg;
 }
function getRetirada() : ?string{
return $this->retirada;
 }
function setRetirada($arg){
 $this->retirada = ($arg === '' || $arg === null) ? null : $arg;
 }
function getDevolucao() : ?string{
return $this->devolucao;
 }
function setDevolucao($arg){
 $this->devolucao = ($arg === '' || $arg === null) ? null : $arg;
 }
function getSituacao() : ?string{
return $this->situacao;
 }
function setSituacao($arg){
 $this->situacao = ($arg === '' || $arg === null) ? null : $arg;
 }
function getMulta() : ?float{
return $this->multa;
 }
function setMulta($arg){
 if (is_string($arg)) $arg = str_replace(',', '.', $arg);
 $this->multa = ($arg === '' || $arg === null) ? null : $arg;
 }
function getCodigo_livro() : ?int{
return $this->codigo_livro;
 }
function setCodigo_livro($arg){
 $this->codigo_livro = ($arg === '' || $arg === null) ? null : $arg;
 }

function __toString(){
return  "leitor :".$this->leitor."<br>".
 "retirada :".$this->retirada."<br>".
 "devolucao :".$this->devolucao."<br>".
 "situacao :".$this->situacao."<br>".
 "multa :".$this->multa."<br>".
 "codigo_livro :".$this->codigo_livro."<br>";
}
}