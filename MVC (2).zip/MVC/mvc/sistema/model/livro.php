<?php
class Livro {
   private ?int $codigo = null;
   private ?string $titulo = null;
   private ?int $paginas = null;
   private ?float $preco = null;
   private ?string $resumo = null;
   private ?int $disponivel = null;

function getCodigo() : ?int{
return $this->codigo;
 }
function setCodigo($arg){
 $this->codigo = ($arg === '' || $arg === null) ? null : $arg;
 }
function getTitulo() : ?string{
return $this->titulo;
 }
function setTitulo($arg){
 $this->titulo = ($arg === '' || $arg === null) ? null : $arg;
 }
function getPaginas() : ?int{
return $this->paginas;
 }
function setPaginas($arg){
 $this->paginas = ($arg === '' || $arg === null) ? null : $arg;
 }
function getPreco() : ?float{
return $this->preco;
 }
function setPreco($arg){
 if (is_string($arg)) $arg = str_replace(',', '.', $arg);
 $this->preco = ($arg === '' || $arg === null) ? null : $arg;
 }
function getResumo() : ?string{
return $this->resumo;
 }
function setResumo($arg){
 $this->resumo = ($arg === '' || $arg === null) ? null : $arg;
 }
function getDisponivel() : ?int{
return $this->disponivel;
 }
function setDisponivel($arg){
 $this->disponivel = ($arg === '' || $arg === null) ? null : $arg;
 }

function __toString(){
return  "titulo :".$this->titulo."<br>".
 "paginas :".$this->paginas."<br>".
 "preco :".$this->preco."<br>".
 "resumo :".$this->resumo."<br>".
 "disponivel :".$this->disponivel."<br>";
}
}