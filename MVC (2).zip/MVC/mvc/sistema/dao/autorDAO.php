<?php
require_once(__DIR__ . "/../model/autor.php");
require_once(__DIR__ . "/../model/conexao.php");
class AutorDAO
{
    private PDO $conexao;
    public function __construct()
    {
        $this->conexao = Conexao::conectar();
    }
    public function inserir(Autor $obj): bool
    {
      try{
        $sql = "insert into autor (nome,pais,nascimento) values(?,?,?)";
        $stmt = $this->conexao->prepare($sql);
        $stmt->bindValue(1,$obj->getNome());
		$stmt->bindValue(2,$obj->getPais());
		$stmt->bindValue(3,$obj->getNascimento());
		
        $stmt->execute();
        header("Location: ../view/lista_autor.php");
        exit();
        return true;
        }catch (PDOException $e){
           echo $e->getMessage();
           return false;
        }
        
    }
    public function alterar(Autor $objeto): bool
    {
      try{
        $sql = "UPDATE autor SET nome = ?,pais = ?,nascimento = ? WHERE codigo = ?";
        $stmt = $this->conexao->prepare($sql);
        $stmt->bindValue(1,$objeto->getNome());
		$stmt->bindValue(2,$objeto->getPais());
		$stmt->bindValue(3,$objeto->getNascimento());
		$stmt->bindValue(4,$objeto->getCodigo());
		
        $stmt->execute();
        header("Location: ../view/lista_autor.php");
        exit();
        }catch (PDOException $e){
           echo $e->getMessage();
           return false;
        }
        
    }
    public function excluir(int $id)
    {
        $sql = "DELETE FROM autor WHERE codigo = :id";
        $stmt = $this->conexao->prepare($sql);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        header("Location: ../view/lista_autor.php");
        exit();
    }
    public function buscarPorId(int $id): ?Autor
    {
        $sql="select * from autor where codigo = :id";
        $stmt= $this->conexao->prepare($sql);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchObject("Autor");
    }
    public function listar(): array
    {
        $sql="select * from autor";
        $stmt = $this->conexao->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll();
        
    }
}
?>