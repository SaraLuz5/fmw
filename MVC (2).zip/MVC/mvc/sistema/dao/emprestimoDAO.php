<?php
require_once(__DIR__ . "/../model/emprestimo.php");
require_once(__DIR__ . "/../model/conexao.php");
class EmprestimoDAO
{
    private PDO $conexao;
    public function __construct()
    {
        $this->conexao = Conexao::conectar();
    }
    public function inserir(Emprestimo $obj): bool
    {
      try{
        $sql = "insert into emprestimo (leitor,retirada,devolucao,situacao,multa,codigo_livro) values(?,?,?,?,?,?)";
        $stmt = $this->conexao->prepare($sql);
        $stmt->bindValue(1,$obj->getLeitor());
		$stmt->bindValue(2,$obj->getRetirada());
		$stmt->bindValue(3,$obj->getDevolucao());
		$stmt->bindValue(4,$obj->getSituacao());
		$stmt->bindValue(5,$obj->getMulta());
		$stmt->bindValue(6,$obj->getCodigo_livro());
		
        $stmt->execute();
        header("Location: ../view/lista_emprestimo.php");
        exit();
        return true;
        }catch (PDOException $e){
           echo $e->getMessage();
           return false;
        }
        
    }
    public function alterar(Emprestimo $objeto): bool
    {
      try{
        $sql = "UPDATE emprestimo SET leitor = ?,retirada = ?,devolucao = ?,situacao = ?,multa = ?,codigo_livro = ? WHERE id = ?";
        $stmt = $this->conexao->prepare($sql);
        $stmt->bindValue(1,$objeto->getLeitor());
		$stmt->bindValue(2,$objeto->getRetirada());
		$stmt->bindValue(3,$objeto->getDevolucao());
		$stmt->bindValue(4,$objeto->getSituacao());
		$stmt->bindValue(5,$objeto->getMulta());
		$stmt->bindValue(6,$objeto->getCodigo_livro());
		$stmt->bindValue(7,$objeto->getId());
		
        $stmt->execute();
        header("Location: ../view/lista_emprestimo.php");
        exit();
        }catch (PDOException $e){
           echo $e->getMessage();
           return false;
        }
        
    }
    public function excluir(int $id)
    {
        $sql = "DELETE FROM emprestimo WHERE id = :id";
        $stmt = $this->conexao->prepare($sql);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        header("Location: ../view/lista_emprestimo.php");
        exit();
    }
    public function buscarPorId(int $id): ?Emprestimo
    {
        $sql="select * from emprestimo where id = :id";
        $stmt= $this->conexao->prepare($sql);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchObject("Emprestimo");
    }
    public function listar(): array
    {
        $sql="select * from emprestimo";
        $stmt = $this->conexao->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll();
        
    }
}
?>