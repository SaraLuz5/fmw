<?php
require_once(__DIR__ . "/../model/livro.php");
require_once(__DIR__ . "/../model/conexao.php");
class LivroDAO
{
    private PDO $conexao;
    public function __construct()
    {
        $this->conexao = Conexao::conectar();
    }
    public function inserir(Livro $obj): bool
    {
      try{
        $sql = "insert into livro (titulo,paginas,preco,resumo,disponivel) values(?,?,?,?,?)";
        $stmt = $this->conexao->prepare($sql);
        $stmt->bindValue(1,$obj->getTitulo());
		$stmt->bindValue(2,$obj->getPaginas());
		$stmt->bindValue(3,$obj->getPreco());
		$stmt->bindValue(4,$obj->getResumo());
		$stmt->bindValue(5,$obj->getDisponivel());
		
        $stmt->execute();
        header("Location: ../view/lista_livro.php");
        exit();
        return true;
        }catch (PDOException $e){
           echo $e->getMessage();
           return false;
        }
        
    }
    public function alterar(Livro $objeto): bool
    {
      try{
        $sql = "UPDATE livro SET titulo = ?,paginas = ?,preco = ?,resumo = ?,disponivel = ? WHERE codigo = ?";
        $stmt = $this->conexao->prepare($sql);
        $stmt->bindValue(1,$objeto->getTitulo());
		$stmt->bindValue(2,$objeto->getPaginas());
		$stmt->bindValue(3,$objeto->getPreco());
		$stmt->bindValue(4,$objeto->getResumo());
		$stmt->bindValue(5,$objeto->getDisponivel());
		$stmt->bindValue(6,$objeto->getCodigo());
		
        $stmt->execute();
        header("Location: ../view/lista_livro.php");
        exit();
        }catch (PDOException $e){
           echo $e->getMessage();
           return false;
        }
        
    }
    public function excluir(int $id)
    {
        $sql = "DELETE FROM livro WHERE codigo = :id";
        $stmt = $this->conexao->prepare($sql);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        header("Location: ../view/lista_livro.php");
        exit();
    }
    public function buscarPorId(int $id): ?Livro
    {
        $sql="select * from livro where codigo = :id";
        $stmt= $this->conexao->prepare($sql);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchObject("Livro");
    }
    public function listar(): array
    {
        $sql="select * from livro";
        $stmt = $this->conexao->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll();
        
    }
}
?>