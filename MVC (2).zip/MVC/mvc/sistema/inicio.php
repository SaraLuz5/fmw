<!doctype html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
<title>Início</title>
<style>
    *{ box-sizing: border-box; }
    body{
        margin: 0;
        padding: 28px;
        font-family: "Segoe UI", Arial, sans-serif;
        background: #fff5f9;
        color: #831843;
    }
    h2{
        margin: 0 0 6px;
        font-size: 1.5rem;
    }
    p.subtitulo{
        margin: 0 0 26px;
        color: #be185d;
    }
    .grade{
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
        gap: 16px;
    }
    .cartao{
        display: flex;
        align-items: center;
        gap: 14px;
        padding: 18px;
        border-radius: 8px;
        background: #fdf2f8;
        border: 1px solid #fbcfe8;
        text-decoration: none;
        color: inherit;
    }
    .cartao:hover{
        border-color: #ec4899;
        box-shadow: 0 4px 12px rgba(236,72,153,.25);
    }
    .cartao-texto h3{
        margin: 0 0 4px;
        font-size: 1.05rem;
    }
    .cartao-texto p{
        margin: 0;
        font-size: .85rem;
        color: #be185d;
    }
</style>
</head>
<body>
    <h2>Bem-vindo!</h2>
    <p class="subtitulo">Escolha uma tabela abaixo para listar, ou use o menu ao lado para cadastrar um novo registro.</p>
    <div class="grade">
        <a class="cartao" href="view/lista_autor.php" target="principal">
    <div class="cartao-texto">
        <h3>Autor</h3>
        <p><?php
            require_once __DIR__ . "/dao/autorDAO.php";
            echo count((new AutorDAO())->listar());
        ?> registro(s) · 4 coluna(s)</p>
    </div>
</a>
<a class="cartao" href="view/lista_livro.php" target="principal">
    <div class="cartao-texto">
        <h3>Livro</h3>
        <p><?php
            require_once __DIR__ . "/dao/livroDAO.php";
            echo count((new LivroDAO())->listar());
        ?> registro(s) · 6 coluna(s)</p>
    </div>
</a>
<a class="cartao" href="view/lista_emprestimo.php" target="principal">
    <div class="cartao-texto">
        <h3>Emprestimo</h3>
        <p><?php
            require_once __DIR__ . "/dao/emprestimoDAO.php";
            echo count((new EmprestimoDAO())->listar());
        ?> registro(s) · 7 coluna(s)</p>
    </div>
</a>

    </div>
</body>
</html>