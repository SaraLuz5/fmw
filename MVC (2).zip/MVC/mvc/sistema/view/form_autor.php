<html>
    <head>
        <title>Cadastro</title>
          <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
          <style>
            body{ background:#fff5f9; color:#831843; }
            h2{ color:#9d174d; }
            a{ color:#be185d; }
            a:hover{ color:#831843; }
            .table-dark{ --bs-table-bg:#be185d; --bs-table-border-color:#9d174d; --bs-table-color:#fff; }
            .table-striped>tbody>tr:nth-of-type(odd)>*{ --bs-table-bg-type:#fdf2f8; }
            .table>:not(caption)>*>*{ border-color:#fbcfe8; }
            .btn-primary{ --bs-btn-bg:#db2777; --bs-btn-border-color:#db2777; --bs-btn-hover-bg:#be185d; --bs-btn-hover-border-color:#be185d; --bs-btn-active-bg:#9d174d; --bs-btn-active-border-color:#9d174d; --bs-btn-color:#fff; --bs-btn-hover-color:#fff; }
            .form-control:focus{ border-color:#f472b6; box-shadow:0 0 0 .25rem rgba(236,72,153,.25); }
        </style>
    </head>
    <body>
    <?php
     $alt=false;
       if(isset($obj))
       $alt=true;
    ?>
    <div class="container mt-5">
    <h2 class="mb-4">Cadastro</h2>
    <form action="../control/autorControl.php" method="POST">
    <input type="hidden" name="acao" value="<?php echo ($alt)?5:1;?>">
    <?php if($alt): ?>
			<input type="hidden" name="codigo" value="<?php echo $obj->getCodigo();?>">
			<?php endif; ?>
      <div class="mb-3"><label for="nome" class="form-label">nome</label><input value='<?php echo ($alt)?$obj->getNome():"";?>'  type='text' name='nome' class="form-control"></div>
	<div class="mb-3"><label for="pais" class="form-label">pais</label><input value='<?php echo ($alt)?$obj->getPais():"";?>'  type='text' name='pais' class="form-control"></div>
	<div class="mb-3"><label for="nascimento" class="form-label">nascimento</label><input value='<?php echo ($alt)?$obj->getNascimento():"";?>'  type='date' name='nascimento' class="form-control"></div>
	
      <button type="submit" class="btn btn-primary">Salvar</button>
    </form>
    </body>
</html>