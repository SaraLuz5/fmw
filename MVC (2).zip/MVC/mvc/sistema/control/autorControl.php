<?PHP
require_once('../model/autor.php');
 require_once('../dao/autorDAO.php');
class AutorControl {
   private $obj;
   private $dao;
   private $acao;
   public function __construct() {
       $this->obj=new Autor();
       $this->dao=new AutorDAO();
       $this->acao=$_REQUEST["acao"] ?? null;
      $this->executaAcao();
   }
   public function executaAcao() {
   switch($this->acao) {
          case 1:
          $this->prepararObjeto();
          $this->dao->inserir( $this->obj);
          break;
          case 2:
          return $this->dao->listar();
          case 3:
          $this->dao->excluir( $_REQUEST["id"] );
          break;
          case 4:
          $obj=$this->dao->buscarPorId( $_REQUEST["id"] );
          require_once("../view/form_autor.php");
          break;
          case 5:
          $this->prepararObjeto();
          $this->dao->alterar( $this->obj);
          break;
      }
   }
   public function prepararObjeto() {
      $this->obj->setNome($_POST["nome"]);
	$this->obj->setPais($_POST["pais"]);
	$this->obj->setNascimento($_POST["nascimento"]);
	if(isset($_POST["codigo"]))
	$this->obj->setCodigo($_POST["codigo"]);
	
   }
}
new AutorControl;
?>