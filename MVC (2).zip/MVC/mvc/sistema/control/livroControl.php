<?PHP
require_once('../model/livro.php');
 require_once('../dao/livroDAO.php');
class LivroControl {
   private $obj;
   private $dao;
   private $acao;
   public function __construct() {
       $this->obj=new Livro();
       $this->dao=new LivroDAO();
       $this->acao=$_REQUEST["acao"] ?? null;
      $this->executaAcao();
   }
   public function executaAcao() {
   switch($this->acao) {
          case 1:
          $this->prepararObjeto();
          $this->dao->inserir( $this->obj);
          break;
          case 2:
          return $this->dao->listar();
          case 3:
          $this->dao->excluir( $_REQUEST["id"] );
          break;
          case 4:
          $obj=$this->dao->buscarPorId( $_REQUEST["id"] );
          require_once("../view/form_livro.php");
          break;
          case 5:
          $this->prepararObjeto();
          $this->dao->alterar( $this->obj);
          break;
      }
   }
   public function prepararObjeto() {
      $this->obj->setTitulo($_POST["titulo"]);
	$this->obj->setPaginas($_POST["paginas"]);
	$this->obj->setPreco($_POST["preco"]);
	$this->obj->setResumo($_POST["resumo"]);
	$this->obj->setDisponivel($_POST["disponivel"]);
	if(isset($_POST["codigo"]))
	$this->obj->setCodigo($_POST["codigo"]);
	
   }
}
new LivroControl;
?>