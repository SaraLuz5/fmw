<?PHP
require_once('../model/emprestimo.php');
 require_once('../dao/emprestimoDAO.php');
class EmprestimoControl {
   private $obj;
   private $dao;
   private $acao;
   public function __construct() {
       $this->obj=new Emprestimo();
       $this->dao=new EmprestimoDAO();
       $this->acao=$_REQUEST["acao"] ?? null;
      $this->executaAcao();
   }
   public function executaAcao() {
   switch($this->acao) {
          case 1:
          $this->prepararObjeto();
          $this->dao->inserir( $this->obj);
          break;
          case 2:
          return $this->dao->listar();
          case 3:
          $this->dao->excluir( $_REQUEST["id"] );
          break;
          case 4:
          $obj=$this->dao->buscarPorId( $_REQUEST["id"] );
          require_once("../view/form_emprestimo.php");
          break;
          case 5:
          $this->prepararObjeto();
          $this->dao->alterar( $this->obj);
          break;
      }
   }
   public function prepararObjeto() {
      $this->obj->setLeitor($_POST["leitor"]);
	$this->obj->setRetirada($_POST["retirada"]);
	$this->obj->setDevolucao($_POST["devolucao"]);
	$this->obj->setSituacao($_POST["situacao"]);
	$this->obj->setMulta($_POST["multa"]);
	$this->obj->setCodigo_livro($_POST["codigo_livro"]);
	if(isset($_POST["id"]))
	$this->obj->setId($_POST["id"]);
	
   }
}
new EmprestimoControl;
?>