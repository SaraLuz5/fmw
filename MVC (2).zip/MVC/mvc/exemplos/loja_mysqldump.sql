DROP TABLE IF EXISTS `categoria`;
CREATE TABLE `categoria` (
  `id` int NOT NULL AUTO_INCREMENT,
  `descricao` varchar(60) NOT NULL,
  `ativa` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `descricao` (`descricao`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;


LOCK TABLES `categoria` WRITE;
INSERT INTO `categoria` VALUES (1,'Bebidas',1),(2,'Livros',1),(3,'Informática',0);
UNLOCK TABLES;

DROP TABLE IF EXISTS `produto`;
CREATE TABLE `produto` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(120) NOT NULL,
  `preco` decimal(10,2) NOT NULL DEFAULT '0.00',
  `estoque` int NOT NULL DEFAULT '0',
  `situacao` enum('novo','usado','recondicionado') NOT NULL DEFAULT 'novo',
  `descricao` text,
  `id_categoria` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_produto_categoria` (`id_categoria`),
  CONSTRAINT `fk_produto_categoria` FOREIGN KEY (`id_categoria`) REFERENCES `categoria` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

LOCK TABLES `produto` WRITE;
INSERT INTO `produto` VALUES (1,'Café torrado',24.90,120,'novo','Grãos fortes',1),(2,'Teclado',349.00,8,'recondicionado','azul',3);
UNLOCK TABLES;


DROP TABLE IF EXISTS `cliente`;
CREATE TABLE `cliente` (
  `id_cliente` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(120) NOT NULL,
  `email` varchar(120) NOT NULL,
  `nascimento` date DEFAULT NULL,
  `cadastrado_em` datetime DEFAULT CURRENT_TIMESTAMP,
  `limite_credito` double DEFAULT NULL,
  PRIMARY KEY (`id_cliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

LOCK TABLES `cliente` WRITE;
INSERT INTO `cliente` VALUES (1,'Marina Duarte','marina@exemplo.com','1995-02-11','2026-02-01 09:30:00',2500);
UNLOCK TABLES;
