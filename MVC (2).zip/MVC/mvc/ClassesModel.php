<?php
require_once ("utils.php");
class ClassesModel{
private $entidades;
    private  $caminho = "sistema/model/";
    function __construct($e) {
        if (!is_dir($this->caminho)) {
            mkdir($this->caminho, 0777, true);
        }
        $this->entidades = $e;
        $this->criaClasses();
    }
    function criaClasses() {
            $util = new Utils();
            $listaEntidades = array_keys($this->entidades);
            foreach ($listaEntidades as $entidade) {
                $listaAtributos = $this->entidades[$entidade];
                $attr = "";
                $metodos = "";
                $magico = "";
                foreach ($listaAtributos as $key => $atributo) {
                    $tipoPHP = $util->converterTipoPHP($atributo["tipo"]);
                    $tipoNulo = ($tipoPHP === 'mixed') ? 'mixed' : ('?' . $tipoPHP);
                    $attr .= "   private " . $tipoNulo . " $" . $key . " = null;\n";
                    $metodos .= "function get" . ucfirst($key) . "() : " . $tipoNulo . "{\n";
                    $metodos .= "return \$this->" . $key . ";\n }\n";
                    $metodos .= "function set" . ucfirst($key) . "(\$arg){\n";
                    if ($tipoPHP === 'float') {
                        // aceita tanto "39.90" quanto "39,90" (formato brasileiro)
                        $metodos .= " if (is_string(\$arg)) \$arg = str_replace(',', '.', \$arg);\n";
                    }
                    $metodos .= " \$this->" . $key . " = (\$arg === '' || \$arg === null) ? null : \$arg;\n }\n";
                    if(!$atributo["primary"])
                    $magico .= " \"$key :\".\$this->$key.\"<br>\".\n";
                }
                $magico = substr($magico, 0, -2);
                $nomeClasse = ucfirst($entidade);
                $conteudo = <<<CLASS
                <?php
                class $nomeClasse {
                $attr
                $metodos
                function __toString(){
                return $magico;
                }
                }
                CLASS;
                file_put_contents("$this->caminho" . $entidade . ".php", $conteudo);
        }
    }
}
?>