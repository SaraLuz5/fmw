<?php
require_once "Calculadora.php";
require_once "ObjetoMensagem.php";
require_once "Router.php";
$router = new Router();
$router->add("somar", "Calculadora", "somar");
$router->run();


