<?php
class Router
{
    private $rotas = [];
    public function add($url, $classe, $metodo)
    {
        $this->rotas[$url] = [
            'classe' => $classe,
            'metodo' => $metodo
        ];
    }
    public function run()
    {
        $urlAtual = $_GET['url'] ?? '';
        if (array_key_exists($urlAtual, $this->rotas)) {
            $nomeClasse = $this->rotas[$urlAtual]['classe'];
            $nomeMetodo = $this->rotas[$urlAtual]['metodo'];
            $objeto = new $nomeClasse();
            echo $objeto->$nomeMetodo();
        } else {
            http_response_code(404);
            echo "Rota {$urlAtual} não encontrado";
        }
    }
}
