<?php

class Loja
{
    public function venda()
    {
        $a = $_GET['vestido'] ?? 0;
        $a = $_GET['blusa'] ?? 0;
        $a = $_GET['calça'] ?? 0;
        $a = $_GET['saia'] ?? 0;

        return "A escolha foi: " .  $a;
    }

    public function soma()
    {
        $a = $_GET['a'] ?? 0;
        $b = $_GET['b'] ?? 0;

        return "Resultado da subtração: " . ($a - $b);
    }

}
