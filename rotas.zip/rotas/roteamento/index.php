<?php

require_once "Calculadora.php";
require_once "ObjetoMensagem.php";
$url = $_GET["url"];
switch ($url){
    case "somar":
        $calc = new Calculadora();
        $a = $_GET["a"] ?? 0;
        $b = $_GET["b"] ?? 0;
        echo "Resultado da soma : " .$calc->somar($a , $b);
        break;

    case "subtrair":
        $calc = new Calculadora();
        $a = $_GET["a"] ?? 0;
        $b = $_GET["b"] ?? 0;
        echo "Resultado da subtração : " .$calc->subtrair($a , $b);
    
    case "dividir":
        $calc = new Calculadora();
        $a = $_GET["a"] ?? 0;
        $b = $_GET["b"] ?? 0;
        echo "Resultado da divisão : " .$calc->dividir($a , $b);

    case "multiplicar":
        $calc = new Calculadora();
        $a = $_GET["a"] ?? 0;
        $b = $_GET["b"] ?? 0;
        echo "Resultado da multiplicação : " .$calc->multiplicar($a , $b);

    case "criar-objeto":
        $nome = $_GET["nome"] ?? "Objeto padrão";
        $obj = new ObjetoMensagem($nome);
        echo "<h1>".$obj->criar()."</h1>";
        break;
}