<?php
$estado = $_GET['estado'] ?? '';
if(empty($estado)){
    echo '<option value = "">Selecione um estado primeiro...</option>';
    exit;
}
$cidadePorEstado = [
    'SP' => ['São Paulo' , 'Campinas' , 'Santos' , 'Ribeirão Preto'],
    'RJ' => ['Rio de Janeiro' , 'Niterói' , 'Petrópolis' , 'Cabo Frio'],
    'PR' => ['Curitiba' , 'Foz do Iguaçu' , 'Maringá' , 'Londrina'],
];
$listaCidades = $cidadePorEstado[$estado] ?? [];

if(count($listaCidades)>0){
    foreach ($listaCidades as $cidade) {
        echo '<option value="' . $cidade . '">' . $cidade . '</option>';
    }
}