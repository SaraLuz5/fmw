<?php
$estado = $_GET['estado'] ?? '';
if (empty($estado)) {
    echo '<option value="">Selecione um estado...</option>';
    exit;
}
$cidadesPorEstado = [
    'SP' => ['São Paulo', 'Campinas', 'Santos', 'Ribeirao Preto'],
    'RJ' => ['Rio de Janeiro', 'Niterói', 'Petrópolis', 'Cabo Frio'],
    'PR' => ['Curitiba', 'Londrina', 'Maringá', 'Foz do Iguaçu'],
];
$listaCidades = $cidadesPorEstado[$estado] ?? [];

if(count($listaCidades) > 0){
    foreach($listaCidades as $cidade){
        echo '<option value="'.$cidade.'">'.$cidade.'</option>';
    }
}