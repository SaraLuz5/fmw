<?php

$senha = $resposta