let dados = [1, 3, 21, 24, 5, 1, 13, 2, 17, 3];
const media = document.getElementById("media");
const mediana = document.getElementById("mediana");
const moda = document.getElementById("moda");
const variancia = document.getElementById("variancia");
const desPadrao = document.getElementById("desvPadrao");
const coefVariacao = document.getElementById("coefVariacao");

function calcularMedia() {
    let soma = 0;
    for (let i = 0; i < dados.length; i++) {
        soma += dados[i];
    }
    return soma / dados.length;
    // return dados.reduce((acc, dado) => acc + dado) / dados.length;
}

function calcularMediana() {
    let numeros = dados;
    numeros.sort((a, b) => a - b);
    let meio = Math.floor(numeros.length / 2);

    if (numeros.length % 2 === 0) {
        return (numeros[meio - 1] + numeros[meio]) / 2;
    } else {
        return numeros[meio];
    }
}
function calcularModa() {
    let frequencias = {};

    for (let i = 0; i < dados.length; i++) {
        let numero = dados[i];

        if (frequencias[numero]) {
            frequencias[numero]++;
        } else {
            frequencias[numero] = 1;
        }
    }

    let maiorFrequencia = 0;
    let moda = [];

    for (numero in frequencias) {
        if (frequencias[numero] > maiorFrequencia) {
            maiorFrequencia = frequencias[numero];
            moda = [numero];
        } else if (frequencias[numero] === maiorFrequencia) {
            moda.push(numero);
        }
    }

    return moda.join(", ");
}
function calcularVariancia() {
    let media = calcularMedia();
    let soma = 0;

    for(let i= 0; i< dados.length; i ++){
        soma += Math.pow(dados[i] - media, 2);
    }
     return soma / dados.length;

}
function calcularDesvioPadrao() {
    let desvio = Math.sqrt(calcularVariancia());
    return desvio;
}
function calcularCoeficienteDeVariacao() {
    let coeficiente = (calcularDesvioPadrao() / calcularMedia()) * 100;
    return coeficiente;
}
media.innerHTML = calcularMedia().toFixed(2);
mediana.innerHTML = calcularMediana();
moda.innerHTML = calcularModa();
variancia.innerHTML = calcularVariancia();
desPadrao.innerHTML = calcularDesvioPadrao().toFixed(2);
coefVariacao.innerHTML = calcularCoeficienteDeVariacao().toFixed(2) + "%";