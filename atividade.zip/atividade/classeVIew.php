<?php
require_once ("utils.php");
class ClassesView{
private $entidades;
private $caminho = "sistema/view/";
    function __construct($e) {
        if (!is_dir($this->caminho)) {
            mkdir($this->caminho, 0777, true);
        }
        $this->entidades = $e;
        $this->criaFormulario();
        $this->criaResultado();
    }
    function criaFormulario() {
            $util = new Utils();
            $listaEntidades = array_keys($this->entidades);
            foreach ($listaEntidades as $entidade) {
                $listaAtributos = $this->entidades[$entidade];
                $campos = "";
                foreach ($listaAtributos as $key => $atributo) {
                    if(!$atributo["primary"]) {
                        $tipoForm = $util->converterTipoPHPForm($atributo["tipo"]);
                        $campos .= "<div class=\"mb-3\">";
                        $campos .= "<label for=\"$key\" class=\"form-label\">$key</label>";
                        $campos .= "<input type='" . $tipoForm . "' name='" . $key . "' class=\"form-control\">";
                        $campos .= "</div>\n\t";
                    }
                }
                $conteudo = <<<FORM
                <html>
                    <head>
                        <title>Cadastro</title>
                          <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
                    </head>
                    <body>
                    <div class="container mt-5">
                    <h2 class="mb-4">Cadastro</h2>
                    <form action="../control/{$entidade}Control.php" method="POST">
                    <input type="hidden" name="acao" value="1">
                      $campos
                      <button type="submit" class="btn btn-primary">Salvar</button>
                    </form>
                    <a href="listar_{$entidade}.php" class="btn btn-link mt-3">Ver lista de {$entidade}</a>
                    </div>
                    </body>
                </html>
                FORM;
                file_put_contents("{$this->caminho}form_" . $entidade . ".php", $conteudo);
        }
    }

    function criaResultado() {
            $listaEntidades = array_keys($this->entidades);
            foreach ($listaEntidades as $entidade) {
                $listaAtributos = $this->entidades[$entidade];

                // Monta cabeçalho e colunas da tabela dinamicamente a partir dos atributos
                $cabecalho = "";
                $colunas = "";
                foreach ($listaAtributos as $key => $atributo) {
                    $cabecalho .= "<th>$key</th>\n\t\t\t\t\t\t";
                    $colunas  .= "<td><?= \$item->get" . ucfirst($key) . "() ?></td>\n\t\t\t\t\t\t";
                }

                // Página que exibe o resultado da busca em tabela (incluída pelo Control)
                $conteudoResultado = <<<RESULT
                <html>
                    <head>
                        <title>Resultado da Busca</title>
                        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
                    </head>
                    <body>
                    <div class="container mt-5">
                    <h2 class="mb-4">Resultado da Busca</h2>
                    <table class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                $cabecalho
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach (\$lista as \$item): ?>
                            <tr>
                                $colunas
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <a href="form_{$entidade}.php" class="btn btn-secondary">Voltar</a>
                    </div>
                    </body>
                </html>
                RESULT;
                file_put_contents("{$this->caminho}resultado_" . $entidade . ".php", $conteudoResultado);

                // Página que dispara a solicitação de busca para o Control (acao=2 -> listar)
                $conteudoListar = <<<BUSCA
                <html>
                    <head>
                        <title>Listagem</title>
                        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
                    </head>
                    <body>
                    <div class="container mt-5">
                    <h2 class="mb-4">Listagem de {$entidade}</h2>
                    <form action="../control/{$entidade}Control.php" method="POST">
                    <input type="hidden" name="acao" value="2">
                      <button type="submit" class="btn btn-primary">Listar</button>
                    </form>
                    </div>
                    </body>
                </html>
                BUSCA;
                file_put_contents("{$this->caminho}listar_" . $entidade . ".php", $conteudoListar);
        }
    }
}
?>