<!doctype html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
<title>Painel do sistema</title>
<base target="principal">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
    html, body{ 
        height: 100%; 
        margin: 0; 
    }
    body{ 
        display: flex; 
        flex-direction: column; 
    }
    #conteudo{ 
        flex: 1; 
        padding: 18px; 
        background: #fdf2f8; 
    }
    #conteudo iframe{ 
        width: 100%; 
        height: 100%; 
        border: none; 
        background: #fff; 
    }
</style>
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #4F6D7A;">
        <div class="container-fluid">
            <a class="navbar-brand" href="inicio.php" target="principal"></a>
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="inicio.php" target="principal">Início</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Cadastrar</a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="view/form_especialidade.php">Especialidade</a></li>
<li><a class="dropdown-item" href="view/form_medico.php">Medico</a></li>
<li><a class="dropdown-item" href="view/form_paciente.php">Paciente</a></li>
<li><a class="dropdown-item" href="view/form_consulta.php">Consulta</a></li>
<li><a class="dropdown-item" href="view/form_exame.php">Exame</a></li>

                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Listar</a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="view/lista_especialidade.php">Especialidade</a></li>
<li><a class="dropdown-item" href="view/lista_medico.php">Medico</a></li>
<li><a class="dropdown-item" href="view/lista_paciente.php">Paciente</a></li>
<li><a class="dropdown-item" href="view/lista_consulta.php">Consulta</a></li>
<li><a class="dropdown-item" href="view/lista_exame.php">Exame</a></li>

                    </ul>
                </li>
            </ul>
        </div>
    </nav>

    <div id="conteudo">
        <iframe name="principal" src="inicio.php"></iframe>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>