<!doctype html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
<title>Início</title>
<style>
    *{ box-sizing: border-box; }
    body{
        margin: 0;
        padding: 28px;
        font-family: "Segoe UI", Arial, sans-serif;
        background: #EAEAEA;
        color: #DD6E42;

    }
    h2{
        margin: 0 0 6px;
        font-size: 1.5rem;
    }
    p.subtitulo{
        margin: 0 0 26px;
        color: #4F6D7A;
    }
    .grade{
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
        gap: 16px;
    }
    .cartao{
        display: flex;
        align-items: center;
        gap: 14px;
        padding: 18px;
        border-radius: 8px;
        background: #fdf2f8;
        border: 1px solid #fbcfe8;
        text-decoration: none;
        color: inherit;
    }
    .cartao:hover{
        border-color: color #E1C066;
        box-shadow: 0 4px 12px color #7c6117;
    }
    .cartao-texto h3{
        margin: 0 0 4px;
        font-size: 1.05rem;
    }
    .cartao-texto p{
        margin: 0;
        font-size: .85rem;
        color: #4F6D7A;
    }

</style>
</head>
<body>
    <h2>Bem-vindo!</h2>
    <p class="subtitulo">Escolha uma tabela abaixo para listar, ou use o menu ao lado para cadastrar um novo registro.</p>
    <div class="grade">
        <a class="cartao" href="view/lista_especialidade.php" target="principal">
    <div class="cartao-texto">
        <h3>Especialidade</h3>
        <p><?php
            require_once __DIR__ . "/dao/especialidadeDAO.php";
            echo count((new EspecialidadeDAO())->listar());
        ?> registro(s) · 4 coluna(s)</p>
    </div>
</a>
<a class="cartao" href="view/lista_medico.php" target="principal">
    <div class="cartao-texto">
        <h3>Medico</h3>
        <p><?php
            require_once __DIR__ . "/dao/medicoDAO.php";
            echo count((new MedicoDAO())->listar());
        ?> registro(s) · 6 coluna(s)</p>
    </div>
</a>
<a class="cartao" href="view/lista_paciente.php" target="principal">
    <div class="cartao-texto">
        <h3>Paciente</h3>
        <p><?php
            require_once __DIR__ . "/dao/pacienteDAO.php";
            echo count((new PacienteDAO())->listar());
        ?> registro(s) · 9 coluna(s)</p>
    </div>
</a>
<a class="cartao" href="view/lista_consulta.php" target="principal">
    <div class="cartao-texto">
        <h3>Consulta</h3>
        <p><?php
            require_once __DIR__ . "/dao/consultaDAO.php";
            echo count((new ConsultaDAO())->listar());
        ?> registro(s) · 8 coluna(s)</p>
    </div>
</a>
<a class="cartao" href="view/lista_exame.php" target="principal">
    <div class="cartao-texto">
        <h3>Exame</h3>
        <p><?php
            require_once __DIR__ . "/dao/exameDAO.php";
            echo count((new ExameDAO())->listar());
        ?> registro(s) · 7 coluna(s)</p>
    </div>
</a>

    </div>
</body>
</html>