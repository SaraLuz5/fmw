<?php
class Consulta {
   private ?int $id_consulta = null;
   private ?string $data_hora = null;
   private ?string $queixa = null;
   private ?string $diagnostico = null;
   private ?float $valor = null;
   private ?string $situacao = null;
   private ?int $id_paciente = null;
   private ?int $id_medico = null;

function getId_consulta() : ?int{
return $this->id_consulta;
 }
function setId_consulta($arg){
 $this->id_consulta = ($arg === '' || $arg === null) ? null : $arg;
 }
function getData_hora() : ?string{
return $this->data_hora;
 }
function setData_hora($arg){
 $this->data_hora = ($arg === '' || $arg === null) ? null : $arg;
 }
function getQueixa() : ?string{
return $this->queixa;
 }
function setQueixa($arg){
 $this->queixa = ($arg === '' || $arg === null) ? null : $arg;
 }
function getDiagnostico() : ?string{
return $this->diagnostico;
 }
function setDiagnostico($arg){
 $this->diagnostico = ($arg === '' || $arg === null) ? null : $arg;
 }
function getValor() : ?float{
return $this->valor;
 }
function setValor($arg){
 if (is_string($arg)) $arg = str_replace(',', '.', $arg);
 $this->valor = ($arg === '' || $arg === null) ? null : $arg;
 }
function getSituacao() : ?string{
return $this->situacao;
 }
function setSituacao($arg){
 $this->situacao = ($arg === '' || $arg === null) ? null : $arg;
 }
function getId_paciente() : ?int{
return $this->id_paciente;
 }
function setId_paciente($arg){
 $this->id_paciente = ($arg === '' || $arg === null) ? null : $arg;
 }
function getId_medico() : ?int{
return $this->id_medico;
 }
function setId_medico($arg){
 $this->id_medico = ($arg === '' || $arg === null) ? null : $arg;
 }

function __toString(){
return  "data_hora :".$this->data_hora."<br>".
 "queixa :".$this->queixa."<br>".
 "diagnostico :".$this->diagnostico."<br>".
 "valor :".$this->valor."<br>".
 "situacao :".$this->situacao."<br>".
 "id_paciente :".$this->id_paciente."<br>".
 "id_medico :".$this->id_medico."<br>";
}
}