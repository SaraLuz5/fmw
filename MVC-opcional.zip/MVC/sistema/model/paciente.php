<?php
class Paciente {
   private ?int $id_paciente = null;
   private ?string $nome = null;
   private ?string $cpf = null;
   private ?string $nascimento = null;
   private ?string $sexo = null;
   private ?string $telefone = null;
   private ?string $convenio = null;
   private ?string $alergias = null;
   private ?string $cadastrado_em = null;

function getId_paciente() : ?int{
return $this->id_paciente;
 }
function setId_paciente($arg){
 $this->id_paciente = ($arg === '' || $arg === null) ? null : $arg;
 }
function getNome() : ?string{
return $this->nome;
 }
function setNome($arg){
 $this->nome = ($arg === '' || $arg === null) ? null : $arg;
 }
function getCpf() : ?string{
return $this->cpf;
 }
function setCpf($arg){
 $this->cpf = ($arg === '' || $arg === null) ? null : $arg;
 }
function getNascimento() : ?string{
return $this->nascimento;
 }
function setNascimento($arg){
 $this->nascimento = ($arg === '' || $arg === null) ? null : $arg;
 }
function getSexo() : ?string{
return $this->sexo;
 }
function setSexo($arg){
 $this->sexo = ($arg === '' || $arg === null) ? null : $arg;
 }
function getTelefone() : ?string{
return $this->telefone;
 }
function setTelefone($arg){
 $this->telefone = ($arg === '' || $arg === null) ? null : $arg;
 }
function getConvenio() : ?string{
return $this->convenio;
 }
function setConvenio($arg){
 $this->convenio = ($arg === '' || $arg === null) ? null : $arg;
 }
function getAlergias() : ?string{
return $this->alergias;
 }
function setAlergias($arg){
 $this->alergias = ($arg === '' || $arg === null) ? null : $arg;
 }
function getCadastrado_em() : ?string{
return $this->cadastrado_em;
 }
function setCadastrado_em($arg){
 $this->cadastrado_em = ($arg === '' || $arg === null) ? null : $arg;
 }

function __toString(){
return  "nome :".$this->nome."<br>".
 "cpf :".$this->cpf."<br>".
 "nascimento :".$this->nascimento."<br>".
 "sexo :".$this->sexo."<br>".
 "telefone :".$this->telefone."<br>".
 "convenio :".$this->convenio."<br>".
 "alergias :".$this->alergias."<br>".
 "cadastrado_em :".$this->cadastrado_em."<br>";
}
}