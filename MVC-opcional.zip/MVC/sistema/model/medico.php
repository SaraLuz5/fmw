<?php
class Medico {
   private ?int $id_medico = null;
   private ?string $nome = null;
   private ?string $crm = null;
   private ?string $telefone = null;
   private ?string $email = null;
   private ?int $id_especialidade = null;

function getId_medico() : ?int{
return $this->id_medico;
 }
function setId_medico($arg){
 $this->id_medico = ($arg === '' || $arg === null) ? null : $arg;
 }
function getNome() : ?string{
return $this->nome;
 }
function setNome($arg){
 $this->nome = ($arg === '' || $arg === null) ? null : $arg;
 }
function getCrm() : ?string{
return $this->crm;
 }
function setCrm($arg){
 $this->crm = ($arg === '' || $arg === null) ? null : $arg;
 }
function getTelefone() : ?string{
return $this->telefone;
 }
function setTelefone($arg){
 $this->telefone = ($arg === '' || $arg === null) ? null : $arg;
 }
function getEmail() : ?string{
return $this->email;
 }
function setEmail($arg){
 $this->email = ($arg === '' || $arg === null) ? null : $arg;
 }
function getId_especialidade() : ?int{
return $this->id_especialidade;
 }
function setId_especialidade($arg){
 $this->id_especialidade = ($arg === '' || $arg === null) ? null : $arg;
 }

function __toString(){
return  "nome :".$this->nome."<br>".
 "crm :".$this->crm."<br>".
 "telefone :".$this->telefone."<br>".
 "email :".$this->email."<br>".
 "id_especialidade :".$this->id_especialidade."<br>";
}
}