<?php
class Especialidade {
   private ?int $id_especialidade = null;
   private ?string $nome = null;
   private ?float $valor_consulta = null;
   private ?int $ativa = null;

function getId_especialidade() : ?int{
return $this->id_especialidade;
 }
function setId_especialidade($arg){
 $this->id_especialidade = ($arg === '' || $arg === null) ? null : $arg;
 }
function getNome() : ?string{
return $this->nome;
 }
function setNome($arg){
 $this->nome = ($arg === '' || $arg === null) ? null : $arg;
 }
function getValor_consulta() : ?float{
return $this->valor_consulta;
 }
function setValor_consulta($arg){
 if (is_string($arg)) $arg = str_replace(',', '.', $arg);
 $this->valor_consulta = ($arg === '' || $arg === null) ? null : $arg;
 }
function getAtiva() : ?int{
return $this->ativa;
 }
function setAtiva($arg){
 $this->ativa = ($arg === '' || $arg === null) ? null : $arg;
 }

function __toString(){
return  "nome :".$this->nome."<br>".
 "valor_consulta :".$this->valor_consulta."<br>".
 "ativa :".$this->ativa."<br>";
}
}