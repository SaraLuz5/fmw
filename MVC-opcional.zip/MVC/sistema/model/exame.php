<?php
class Exame {
   private ?int $id_exame = null;
   private ?string $tipo = null;
   private ?string $solicitado_em = null;
   private ?string $resultado = null;
   private ?float $valor = null;
   private ?int $entregue = null;
   private ?int $id_consulta = null;

function getId_exame() : ?int{
return $this->id_exame;
 }
function setId_exame($arg){
 $this->id_exame = ($arg === '' || $arg === null) ? null : $arg;
 }
function getTipo() : ?string{
return $this->tipo;
 }
function setTipo($arg){
 $this->tipo = ($arg === '' || $arg === null) ? null : $arg;
 }
function getSolicitado_em() : ?string{
return $this->solicitado_em;
 }
function setSolicitado_em($arg){
 $this->solicitado_em = ($arg === '' || $arg === null) ? null : $arg;
 }
function getResultado() : ?string{
return $this->resultado;
 }
function setResultado($arg){
 $this->resultado = ($arg === '' || $arg === null) ? null : $arg;
 }
function getValor() : ?float{
return $this->valor;
 }
function setValor($arg){
 if (is_string($arg)) $arg = str_replace(',', '.', $arg);
 $this->valor = ($arg === '' || $arg === null) ? null : $arg;
 }
function getEntregue() : ?int{
return $this->entregue;
 }
function setEntregue($arg){
 $this->entregue = ($arg === '' || $arg === null) ? null : $arg;
 }
function getId_consulta() : ?int{
return $this->id_consulta;
 }
function setId_consulta($arg){
 $this->id_consulta = ($arg === '' || $arg === null) ? null : $arg;
 }

function __toString(){
return  "tipo :".$this->tipo."<br>".
 "solicitado_em :".$this->solicitado_em."<br>".
 "resultado :".$this->resultado."<br>".
 "valor :".$this->valor."<br>".
 "entregue :".$this->entregue."<br>".
 "id_consulta :".$this->id_consulta."<br>";
}
}