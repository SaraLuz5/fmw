<?PHP
require_once('../model/especialidade.php');
 require_once('../dao/especialidadeDAO.php');
class EspecialidadeControl {
   private $obj;
   private $dao;
   private $acao;
   public function __construct() {
       $this->obj=new Especialidade();
       $this->dao=new EspecialidadeDAO();
       $this->acao=$_REQUEST["acao"] ?? null;
      $this->executaAcao();
   }
   public function executaAcao() {
   switch($this->acao) {
          case 1:
          $this->prepararObjeto();
          $this->dao->inserir( $this->obj);
          break;
          case 2:
          return $this->dao->listar();
          case 3:
          $this->dao->excluir( $_REQUEST["id"] );
          break;
          case 4:
          $obj=$this->dao->buscarPorId( $_REQUEST["id"] );
          require_once("../view/form_especialidade.php");
          break;
          case 5:
          $this->prepararObjeto();
          $this->dao->alterar( $this->obj);
          break;
      }
   }
   public function prepararObjeto() {
      $this->obj->setNome($_POST["nome"]);
	$this->obj->setValor_consulta($_POST["valor_consulta"]);
	$this->obj->setAtiva($_POST["ativa"]);
	if(isset($_POST["id_especialidade"]))
	$this->obj->setId_especialidade($_POST["id_especialidade"]);
	
   }
}
new EspecialidadeControl;
?>