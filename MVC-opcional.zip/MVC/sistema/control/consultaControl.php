<?PHP
require_once('../model/consulta.php');
 require_once('../dao/consultaDAO.php');
class ConsultaControl {
   private $obj;
   private $dao;
   private $acao;
   public function __construct() {
       $this->obj=new Consulta();
       $this->dao=new ConsultaDAO();
       $this->acao=$_REQUEST["acao"] ?? null;
      $this->executaAcao();
   }
   public function executaAcao() {
   switch($this->acao) {
          case 1:
          $this->prepararObjeto();
          $this->dao->inserir( $this->obj);
          break;
          case 2:
          return $this->dao->listar();
          case 3:
          $this->dao->excluir( $_REQUEST["id"] );
          break;
          case 4:
          $obj=$this->dao->buscarPorId( $_REQUEST["id"] );
          require_once("../view/form_consulta.php");
          break;
          case 5:
          $this->prepararObjeto();
          $this->dao->alterar( $this->obj);
          break;
      }
   }
   public function prepararObjeto() {
      $this->obj->setData_hora($_POST["data_hora"]);
	$this->obj->setQueixa($_POST["queixa"]);
	$this->obj->setDiagnostico($_POST["diagnostico"]);
	$this->obj->setValor($_POST["valor"]);
	$this->obj->setSituacao($_POST["situacao"]);
	$this->obj->setId_paciente($_POST["id_paciente"]);
	$this->obj->setId_medico($_POST["id_medico"]);
	if(isset($_POST["id_consulta"]))
	$this->obj->setId_consulta($_POST["id_consulta"]);
	
   }
}
new ConsultaControl;
?>