<?PHP
require_once('../model/paciente.php');
 require_once('../dao/pacienteDAO.php');
class PacienteControl {
   private $obj;
   private $dao;
   private $acao;
   public function __construct() {
       $this->obj=new Paciente();
       $this->dao=new PacienteDAO();
       $this->acao=$_REQUEST["acao"] ?? null;
      $this->executaAcao();
   }
   public function executaAcao() {
   switch($this->acao) {
          case 1:
          $this->prepararObjeto();
          $this->dao->inserir( $this->obj);
          break;
          case 2:
          return $this->dao->listar();
          case 3:
          $this->dao->excluir( $_REQUEST["id"] );
          break;
          case 4:
          $obj=$this->dao->buscarPorId( $_REQUEST["id"] );
          require_once("../view/form_paciente.php");
          break;
          case 5:
          $this->prepararObjeto();
          $this->dao->alterar( $this->obj);
          break;
      }
   }
   public function prepararObjeto() {
      $this->obj->setNome($_POST["nome"]);
	$this->obj->setCpf($_POST["cpf"]);
	$this->obj->setNascimento($_POST["nascimento"]);
	$this->obj->setSexo($_POST["sexo"]);
	$this->obj->setTelefone($_POST["telefone"]);
	$this->obj->setConvenio($_POST["convenio"]);
	$this->obj->setAlergias($_POST["alergias"]);
	$this->obj->setCadastrado_em($_POST["cadastrado_em"]);
	if(isset($_POST["id_paciente"]))
	$this->obj->setId_paciente($_POST["id_paciente"]);
	
   }
}
new PacienteControl;
?>