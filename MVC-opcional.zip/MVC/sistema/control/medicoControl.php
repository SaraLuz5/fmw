<?PHP
require_once('../model/medico.php');
 require_once('../dao/medicoDAO.php');
class MedicoControl {
   private $obj;
   private $dao;
   private $acao;
   public function __construct() {
       $this->obj=new Medico();
       $this->dao=new MedicoDAO();
       $this->acao=$_REQUEST["acao"] ?? null;
      $this->executaAcao();
   }
   public function executaAcao() {
   switch($this->acao) {
          case 1:
          $this->prepararObjeto();
          $this->dao->inserir( $this->obj);
          break;
          case 2:
          return $this->dao->listar();
          case 3:
          $this->dao->excluir( $_REQUEST["id"] );
          break;
          case 4:
          $obj=$this->dao->buscarPorId( $_REQUEST["id"] );
          require_once("../view/form_medico.php");
          break;
          case 5:
          $this->prepararObjeto();
          $this->dao->alterar( $this->obj);
          break;
      }
   }
   public function prepararObjeto() {
      $this->obj->setNome($_POST["nome"]);
	$this->obj->setCrm($_POST["crm"]);
	$this->obj->setTelefone($_POST["telefone"]);
	$this->obj->setEmail($_POST["email"]);
	$this->obj->setId_especialidade($_POST["id_especialidade"]);
	if(isset($_POST["id_medico"]))
	$this->obj->setId_medico($_POST["id_medico"]);
	
   }
}
new MedicoControl;
?>