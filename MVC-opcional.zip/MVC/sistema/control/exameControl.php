<?PHP
require_once('../model/exame.php');
 require_once('../dao/exameDAO.php');
class ExameControl {
   private $obj;
   private $dao;
   private $acao;
   public function __construct() {
       $this->obj=new Exame();
       $this->dao=new ExameDAO();
       $this->acao=$_REQUEST["acao"] ?? null;
      $this->executaAcao();
   }
   public function executaAcao() {
   switch($this->acao) {
          case 1:
          $this->prepararObjeto();
          $this->dao->inserir( $this->obj);
          break;
          case 2:
          return $this->dao->listar();
          case 3:
          $this->dao->excluir( $_REQUEST["id"] );
          break;
          case 4:
          $obj=$this->dao->buscarPorId( $_REQUEST["id"] );
          require_once("../view/form_exame.php");
          break;
          case 5:
          $this->prepararObjeto();
          $this->dao->alterar( $this->obj);
          break;
      }
   }
   public function prepararObjeto() {
      $this->obj->setTipo($_POST["tipo"]);
	$this->obj->setSolicitado_em($_POST["solicitado_em"]);
	$this->obj->setResultado($_POST["resultado"]);
	$this->obj->setValor($_POST["valor"]);
	$this->obj->setEntregue($_POST["entregue"]);
	$this->obj->setId_consulta($_POST["id_consulta"]);
	if(isset($_POST["id_exame"]))
	$this->obj->setId_exame($_POST["id_exame"]);
	
   }
}
new ExameControl;
?>