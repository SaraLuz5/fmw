<?php
ini_set('display_errors',1);
ini_set('display_startup_erros',1);
    error_reporting(E_ALL);
  require_once __DIR__.'/../control/especialidadeControl.php';
  $_REQUEST['acao'] = 2;
  $control = new EspecialidadeControl();
  $dados = $control->executaAcao();
?>
<html>
    <head>
        <title>Lista de especialidade</title>
          <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
          <style>
            body{ background:#EAEAEA; color:#DD6E42; }
            h2{ color:#DD6E42; }
            a{ color:#be185d; }
            a:hover{ color:#831843; }
            .table-dark{ --bs-table-bg:#DD6E42; --bs-table-border-color:#9d174d; --bs-table-color:#fff; }
            .table-striped>tbody>tr:nth-of-type(odd)>*{ --bs-table-bg-type:#fdf2f8; }
            .table>:not(caption)>*>*{ border-color:#fbcfe8; }
            .btn-primary{ --bs-btn-bg:#db2777; --bs-btn-border-color:#db2777; --bs-btn-hover-bg:#be185d; --bs-btn-hover-border-color:#be185d; --bs-btn-active-bg:#9d174d; --bs-btn-active-border-color:#9d174d; --bs-btn-color:#fff; --bs-btn-hover-color:#fff; }
            .form-control:focus{ border-color:#f472b6; box-shadow:0 0 0 .25rem rgba(236,72,153,.25); }
        </style>
    </head>
    <body>
    <div class="container mt-4">
    <h2 class="mb-3">Lista de especialidade</h2>
    <table class="table table-striped table-bordered align-middle">
    <thead class="table-dark">
    <tr> <th>id_especialidade</th>
<th>nome</th>
<th>valor_consulta</th>
<th>ativa</th>
<th colspan='2'>Gerenciar</th>
</tr>
    </thead>
    <tbody>
     <?php
        foreach ($dados as $dado) {
      ?>
    <tr><td><?php echo $dado['id_especialidade']?></td>
<td><?php echo $dado['nome']?></td>
<td><?php echo $dado['valor_consulta']?></td>
<td><?php echo $dado['ativa']?></td>
<td>
            <a href='../control/especialidadeControl.php?acao=3&id=<?php echo $dado['id_especialidade'] ?>'>Excluir</a></td>
<td><a href='../control/especialidadeControl.php?acao=4&id=<?php echo $dado['id_especialidade'] ?>'>Alterar</a></td>
</tr>
    <?php
    }
    ?>
    </tbody>
    </table>
    </div>
    </body>
</html>