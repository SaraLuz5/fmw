<?php
ini_set('display_errors',1);
ini_set('display_startup_erros',1);
    error_reporting(E_ALL);
  require_once __DIR__.'/../control/pacienteControl.php';
  $_REQUEST['acao'] = 2;
  $control = new PacienteControl();
  $dados = $control->executaAcao();
?>
<html>
    <head>
        <title>Lista de paciente</title>
          <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
          <style>
            body{ background:#EAEAEA; color:#831843; }
            h2{ color:#DD6E42; }
            a{ color:#DD6E42; }
            a:hover{ color:#831843; }
            .table-dark{ --bs-table-bg:#DD6E42; --bs-table-border-color:#9d174d; --bs-table-color:#fff; }
            .table-striped>tbody>tr:nth-of-type(odd)>*{ --bs-table-bg-type:#fdf2f8; }
            .table>:not(caption)>*>*{ border-color:#fbcfe8; }
            .btn-primary{ --bs-btn-bg:#db2777; --bs-btn-border-color:#db2777; --bs-btn-hover-bg:#DD6E42; --bs-btn-hover-border-color:#be185d; --bs-btn-active-bg:#9d174d; --bs-btn-active-border-color:#9d174d; --bs-btn-color:#fff; --bs-btn-hover-color:#fff; }
            .form-control:focus{ border-color:#f472b6; box-shadow:0 0 0 .25rem color #E1C066; }
        </style>
    </head>
    <body>
    <div class="container mt-4">
    <h2 class="mb-3">Lista de paciente</h2>
    <table class="table table-striped table-bordered align-middle">
    <thead class="table-dark">
    <tr> <th>id_paciente</th>
<th>nome</th>
<th>cpf</th>
<th>nascimento</th>
<th>sexo</th>
<th>telefone</th>
<th>convenio</th>
<th>alergias</th>
<th>cadastrado_em</th>
<th colspan='2'>Gerenciar</th>
</tr>
    </thead>
    <tbody>
     <?php
        foreach ($dados as $dado) {
      ?>
    <tr><td><?php echo $dado['id_paciente']?></td>
<td><?php echo $dado['nome']?></td>
<td><?php echo $dado['cpf']?></td>
<td><?php echo $dado['nascimento']?></td>
<td><?php echo $dado['sexo']?></td>
<td><?php echo $dado['telefone']?></td>
<td><?php echo $dado['convenio']?></td>
<td><?php echo $dado['alergias']?></td>
<td><?php echo $dado['cadastrado_em']?></td>
<td>
            <a href='../control/pacienteControl.php?acao=3&id=<?php echo $dado['id_paciente'] ?>'>Excluir</a></td>
<td><a href='../control/pacienteControl.php?acao=4&id=<?php echo $dado['id_paciente'] ?>'>Alterar</a></td>
</tr>
    <?php
    }
    ?>
    </tbody>
    </table>
    </div>
    </body>
</html>