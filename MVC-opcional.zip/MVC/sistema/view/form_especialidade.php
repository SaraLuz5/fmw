<html>
    <head>
        <title>Cadastro</title>
          <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
          <style>
            body{ background:#EAEAEA; color:#DD6E42; }
            h2{ color:#DD6E42; }
            a{ color:#be185d; }
            a:hover{ color:#831843; }
            .table-dark{ --bs-table-bg:#be185d; --bs-table-border-color:#9d174d; --bs-table-color:#fff; }
            .table-striped>tbody>tr:nth-of-type(odd)>*{ --bs-table-bg-type:#fdf2f8; }
            .table>:not(caption)>*>*{ border-color:#fbcfe8; }
            .btn{ --bs-btn-bg:#DD6E42; --bs-btn-border-color:#DD6E42; --bs-btn-color:#fff; --bs-btn-hover-color:#fff; }
            .form-control:focus{ border-color:#f472b6; box-shadow:0 0 0 .25rem rgba(236,72,153,.25); }
        </style>
    </head>
    <body>
    <?php
     $alt=false;
       if(isset($obj))
       $alt=true;
    ?>
    <div class="container mt-5">
    <h2 class="mb-4">Cadastro</h2>
    <form action="../control/especialidadeControl.php" method="POST">
    <input type="hidden" name="acao" value="<?php echo ($alt)?5:1;?>">
    <?php if($alt): ?>
			<input type="hidden" name="id_especialidade" value="<?php echo $obj->getId_especialidade();?>">
			<?php endif; ?>
      <div class="mb-3"><label for="nome" class="form-label">nome</label><input value='<?php echo ($alt)?$obj->getNome():"";?>'  type='text' name='nome' class="form-control"></div>
	<div class="mb-3"><label for="valor_consulta" class="form-label">valor_consulta</label><input value='<?php echo ($alt)?$obj->getValor_consulta():"";?>'  type='number' name='valor_consulta' class="form-control"></div>
	<div class="mb-3"><label for="ativa" class="form-label">ativa</label><input value='<?php echo ($alt)?$obj->getAtiva():"";?>'  type='number' name='ativa' class="form-control"></div>
	
      <button type="submit" class="btn btn-primary">Salvar</button>
    </form>
    </body>
</html>