<html>

<head>
  <title>Cadastro</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: #EAEAEA;
      color: #DD6E42;
    }

    h2 {
      color: #DD6E42;
    }

    a {
      color: #DD6E42;
    }

    a:hover {
      color: #DD6E42;
    }

    .table-dark {
      --bs-table-bg: #DD6E42;
      --bs-table-border-color: #9d174d;
      --bs-table-color: #fff;
    }

    .table-striped>tbody>tr:nth-of-type(odd)>* {
      --bs-table-bg-type: #fdf2f8;
    }

    .table>:not(caption)>*>* {
      border-color: #fbcfe8;
    }

    .btn {
      --bs-btn-bg: #DD6E42;
      --bs-btn-border-color: #DD6E42;
      --bs-btn-color: #fff;
      --bs-btn-hover-color: #fff;
    }

    .form-control:focus {
      border-color: #f472b6;
      box-shadow: 0 0 0 .25rem rgba(236, 72, 153, .25);
    }
  </style>
</head>

<body>
  <?php
  $alt = false;
  if (isset($obj))
    $alt = true;
  ?>
  <div class="container mt-5">
    <h2 class="mb-4">Cadastro</h2>
    <form action="../control/pacienteControl.php" method="POST">
      <input type="hidden" name="acao" value="<?php echo ($alt) ? 5 : 1; ?>">
      <?php if ($alt): ?>
        <input type="hidden" name="id_paciente" value="<?php echo $obj->getId_paciente(); ?>">
      <?php endif; ?>
      <div class="mb-3"><label for="nome" class="form-label">nome</label><input value='<?php echo ($alt) ? $obj->getNome() : ""; ?>' type='text' name='nome' class="form-control"></div>
      <div class="mb-3"><label for="cpf" class="form-label">cpf</label><input value='<?php echo ($alt) ? $obj->getCpf() : ""; ?>' type='text' name='cpf' class="form-control"></div>
      <div class="mb-3"><label for="nascimento" class="form-label">nascimento</label><input value='<?php echo ($alt) ? $obj->getNascimento() : ""; ?>' type='date' name='nascimento' class="form-control"></div>
      <div class="mb-3"><label for="sexo" class="form-label">sexo</label><input value='<?php echo ($alt) ? $obj->getSexo() : ""; ?>' type='text' name='sexo' class="form-control"></div>
      <div class="mb-3"><label for="telefone" class="form-label">telefone</label><input value='<?php echo ($alt) ? $obj->getTelefone() : ""; ?>' type='text' name='telefone' class="form-control"></div>
      <div class="mb-3"><label for="convenio" class="form-label">convenio</label><input value='<?php echo ($alt) ? $obj->getConvenio() : ""; ?>' type='text' name='convenio' class="form-control"></div>
      <div class="mb-3"><label for="alergias" class="form-label">alergias</label><input value='<?php echo ($alt) ? $obj->getAlergias() : ""; ?>' type='text' name='alergias' class="form-control"></div>
      <div class="mb-3"><label for="cadastrado_em" class="form-label">cadastrado_em</label><input value='<?php echo ($alt) ? $obj->getCadastrado_em() : ""; ?>' type='datetime-local' name='cadastrado_em' class="form-control"></div>

      <button type="submit" class="btn btn-primary">Salvar</button>
    </form>
</body>

</html>