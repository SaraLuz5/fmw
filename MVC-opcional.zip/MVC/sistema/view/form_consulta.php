<html>
    <head>
        <title>Cadastro</title>
          <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
          <style>
            body{ background:#EAEAEA; color:#DD6E42; }
            h2{ color:#DD6E42; }
            a{ color:#be185d; }
            a:hover{ color:#831843; }
            .table-dark{ --bs-table-bg:#be185d; --bs-table-border-color:#9d174d; --bs-table-color:#fff; }
            .table-striped>tbody>tr:nth-of-type(odd)>*{ --bs-table-bg-type:#fdf2f8; }
            .table>:not(caption)>*>*{ border-color:#fbcfe8; }
            .btn{ --bs-btn-bg:#DD6E42; --bs-btn-border-color:#DD6E42; --bs-btn-color:#fff; --bs-btn-hover-color:#fff; }
            .form-control:focus{ border-color:#f472b6; box-shadow:0 0 0 .25rem rgba(236,72,153,.25); }
        </style>
    </head>
    <body>
    <?php
     $alt=false;
       if(isset($obj))
       $alt=true;
    ?>
    <div class="container mt-5">
    <h2 class="mb-4">Cadastro</h2>
    <form action="../control/consultaControl.php" method="POST">
    <input type="hidden" name="acao" value="<?php echo ($alt)?5:1;?>">
    <?php if($alt): ?>
			<input type="hidden" name="id_consulta" value="<?php echo $obj->getId_consulta();?>">
			<?php endif; ?>
      <div class="mb-3"><label for="data_hora" class="form-label">data_hora</label><input value='<?php echo ($alt)?$obj->getData_hora():"";?>'  type='datetime-local' name='data_hora' class="form-control"></div>
	<div class="mb-3"><label for="queixa" class="form-label">queixa</label><input value='<?php echo ($alt)?$obj->getQueixa():"";?>'  type='text' name='queixa' class="form-control"></div>
	<div class="mb-3"><label for="diagnostico" class="form-label">diagnostico</label><input value='<?php echo ($alt)?$obj->getDiagnostico():"";?>'  type='text' name='diagnostico' class="form-control"></div>
	<div class="mb-3"><label for="valor" class="form-label">valor</label><input value='<?php echo ($alt)?$obj->getValor():"";?>'  type='number' name='valor' class="form-control"></div>
	<div class="mb-3"><label for="situacao" class="form-label">situacao</label><input value='<?php echo ($alt)?$obj->getSituacao():"";?>'  type='text' name='situacao' class="form-control"></div>
	<div class="mb-3"><label for="id_paciente" class="form-label">id_paciente</label><input value='<?php echo ($alt)?$obj->getId_paciente():"";?>'  type='number' name='id_paciente' class="form-control"></div>
	<div class="mb-3"><label for="id_medico" class="form-label">id_medico</label><input value='<?php echo ($alt)?$obj->getId_medico():"";?>'  type='number' name='id_medico' class="form-control"></div>
	
      <button type="submit" class="btn btn-primary">Salvar</button>
    </form>
    </body>
</html>