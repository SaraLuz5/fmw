<?php
require_once(__DIR__ . "/../model/paciente.php");
require_once(__DIR__ . "/../model/conexao.php");
class PacienteDAO
{
    private PDO $conexao;
    public function __construct()
    {
        $this->conexao = Conexao::conectar();
    }
    public function inserir(Paciente $obj): bool
    {
      try{
        $sql = "insert into paciente (nome,cpf,nascimento,sexo,telefone,convenio,alergias,cadastrado_em) values(?,?,?,?,?,?,?,?)";
        $stmt = $this->conexao->prepare($sql);
        $stmt->bindValue(1,$obj->getNome());
		$stmt->bindValue(2,$obj->getCpf());
		$stmt->bindValue(3,$obj->getNascimento());
		$stmt->bindValue(4,$obj->getSexo());
		$stmt->bindValue(5,$obj->getTelefone());
		$stmt->bindValue(6,$obj->getConvenio());
		$stmt->bindValue(7,$obj->getAlergias());
		$stmt->bindValue(8,$obj->getCadastrado_em());
		
        $stmt->execute();
        header("Location: ../view/lista_paciente.php");
        exit();
        return true;
        }catch (PDOException $e){
           echo $e->getMessage();
           return false;
        }
        
    }
    public function alterar(Paciente $objeto): bool
    {
      try{
        $sql = "UPDATE paciente SET nome = ?,cpf = ?,nascimento = ?,sexo = ?,telefone = ?,convenio = ?,alergias = ?,cadastrado_em = ? WHERE id_paciente = ?";
        $stmt = $this->conexao->prepare($sql);
        $stmt->bindValue(1,$objeto->getNome());
		$stmt->bindValue(2,$objeto->getCpf());
		$stmt->bindValue(3,$objeto->getNascimento());
		$stmt->bindValue(4,$objeto->getSexo());
		$stmt->bindValue(5,$objeto->getTelefone());
		$stmt->bindValue(6,$objeto->getConvenio());
		$stmt->bindValue(7,$objeto->getAlergias());
		$stmt->bindValue(8,$objeto->getCadastrado_em());
		$stmt->bindValue(9,$objeto->getId_paciente());
		
        $stmt->execute();
        header("Location: ../view/lista_paciente.php");
        exit();
        }catch (PDOException $e){
           echo $e->getMessage();
           return false;
        }
        
    }
    public function excluir(int $id)
    {
        $sql = "DELETE FROM paciente WHERE id_paciente = :id";
        $stmt = $this->conexao->prepare($sql);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        header("Location: ../view/lista_paciente.php");
        exit();
    }
    public function buscarPorId(int $id): ?Paciente
    {
        $sql="select * from paciente where id_paciente = :id";
        $stmt= $this->conexao->prepare($sql);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchObject("Paciente");
    }
    public function listar(): array
    {
        $sql="select * from paciente";
        $stmt = $this->conexao->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll();
        
    }
}
?>