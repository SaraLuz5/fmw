<?php
require_once(__DIR__ . "/../model/medico.php");
require_once(__DIR__ . "/../model/conexao.php");
class MedicoDAO
{
    private PDO $conexao;
    public function __construct()
    {
        $this->conexao = Conexao::conectar();
    }
    public function inserir(Medico $obj): bool
    {
      try{
        $sql = "insert into medico (nome,crm,telefone,email,id_especialidade) values(?,?,?,?,?)";
        $stmt = $this->conexao->prepare($sql);
        $stmt->bindValue(1,$obj->getNome());
		$stmt->bindValue(2,$obj->getCrm());
		$stmt->bindValue(3,$obj->getTelefone());
		$stmt->bindValue(4,$obj->getEmail());
		$stmt->bindValue(5,$obj->getId_especialidade());
		
        $stmt->execute();
        header("Location: ../view/lista_medico.php");
        exit();
        return true;
        }catch (PDOException $e){
           echo $e->getMessage();
           return false;
        }
        
    }
    public function alterar(Medico $objeto): bool
    {
      try{
        $sql = "UPDATE medico SET nome = ?,crm = ?,telefone = ?,email = ?,id_especialidade = ? WHERE id_medico = ?";
        $stmt = $this->conexao->prepare($sql);
        $stmt->bindValue(1,$objeto->getNome());
		$stmt->bindValue(2,$objeto->getCrm());
		$stmt->bindValue(3,$objeto->getTelefone());
		$stmt->bindValue(4,$objeto->getEmail());
		$stmt->bindValue(5,$objeto->getId_especialidade());
		$stmt->bindValue(6,$objeto->getId_medico());
		
        $stmt->execute();
        header("Location: ../view/lista_medico.php");
        exit();
        }catch (PDOException $e){
           echo $e->getMessage();
           return false;
        }
        
    }
    public function excluir(int $id)
    {
        $sql = "DELETE FROM medico WHERE id_medico = :id";
        $stmt = $this->conexao->prepare($sql);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        header("Location: ../view/lista_medico.php");
        exit();
    }
    public function buscarPorId(int $id): ?Medico
    {
        $sql="select * from medico where id_medico = :id";
        $stmt= $this->conexao->prepare($sql);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchObject("Medico");
    }
    public function listar(): array
    {
        $sql="select * from medico";
        $stmt = $this->conexao->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll();
        
    }
}
?>