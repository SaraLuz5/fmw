<?php
require_once(__DIR__ . "/../model/especialidade.php");
require_once(__DIR__ . "/../model/conexao.php");
class EspecialidadeDAO
{
    private PDO $conexao;
    public function __construct()
    {
        $this->conexao = Conexao::conectar();
    }
    public function inserir(Especialidade $obj): bool
    {
      try{
        $sql = "insert into especialidade (nome,valor_consulta,ativa) values(?,?,?)";
        $stmt = $this->conexao->prepare($sql);
        $stmt->bindValue(1,$obj->getNome());
		$stmt->bindValue(2,$obj->getValor_consulta());
		$stmt->bindValue(3,$obj->getAtiva());
		
        $stmt->execute();
        header("Location: ../view/lista_especialidade.php");
        exit();
        return true;
        }catch (PDOException $e){
           echo $e->getMessage();
           return false;
        }
        
    }
    public function alterar(Especialidade $objeto): bool
    {
      try{
        $sql = "UPDATE especialidade SET nome = ?,valor_consulta = ?,ativa = ? WHERE id_especialidade = ?";
        $stmt = $this->conexao->prepare($sql);
        $stmt->bindValue(1,$objeto->getNome());
		$stmt->bindValue(2,$objeto->getValor_consulta());
		$stmt->bindValue(3,$objeto->getAtiva());
		$stmt->bindValue(4,$objeto->getId_especialidade());
		
        $stmt->execute();
        header("Location: ../view/lista_especialidade.php");
        exit();
        }catch (PDOException $e){
           echo $e->getMessage();
           return false;
        }
        
    }
    public function excluir(int $id)
    {
        $sql = "DELETE FROM especialidade WHERE id_especialidade = :id";
        $stmt = $this->conexao->prepare($sql);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        header("Location: ../view/lista_especialidade.php");
        exit();
    }
    public function buscarPorId(int $id): ?Especialidade
    {
        $sql="select * from especialidade where id_especialidade = :id";
        $stmt= $this->conexao->prepare($sql);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchObject("Especialidade");
    }
    public function listar(): array
    {
        $sql="select * from especialidade";
        $stmt = $this->conexao->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll();
        
    }
}
?>