<?php
require_once(__DIR__ . "/../model/exame.php");
require_once(__DIR__ . "/../model/conexao.php");
class ExameDAO
{
    private PDO $conexao;
    public function __construct()
    {
        $this->conexao = Conexao::conectar();
    }
    public function inserir(Exame $obj): bool
    {
      try{
        $sql = "insert into exame (tipo,solicitado_em,resultado,valor,entregue,id_consulta) values(?,?,?,?,?,?)";
        $stmt = $this->conexao->prepare($sql);
        $stmt->bindValue(1,$obj->getTipo());
		$stmt->bindValue(2,$obj->getSolicitado_em());
		$stmt->bindValue(3,$obj->getResultado());
		$stmt->bindValue(4,$obj->getValor());
		$stmt->bindValue(5,$obj->getEntregue());
		$stmt->bindValue(6,$obj->getId_consulta());
		
        $stmt->execute();
        header("Location: ../view/lista_exame.php");
        exit();
        return true;
        }catch (PDOException $e){
           echo $e->getMessage();
           return false;
        }
        
    }
    public function alterar(Exame $objeto): bool
    {
      try{
        $sql = "UPDATE exame SET tipo = ?,solicitado_em = ?,resultado = ?,valor = ?,entregue = ?,id_consulta = ? WHERE id_exame = ?";
        $stmt = $this->conexao->prepare($sql);
        $stmt->bindValue(1,$objeto->getTipo());
		$stmt->bindValue(2,$objeto->getSolicitado_em());
		$stmt->bindValue(3,$objeto->getResultado());
		$stmt->bindValue(4,$objeto->getValor());
		$stmt->bindValue(5,$objeto->getEntregue());
		$stmt->bindValue(6,$objeto->getId_consulta());
		$stmt->bindValue(7,$objeto->getId_exame());
		
        $stmt->execute();
        header("Location: ../view/lista_exame.php");
        exit();
        }catch (PDOException $e){
           echo $e->getMessage();
           return false;
        }
        
    }
    public function excluir(int $id)
    {
        $sql = "DELETE FROM exame WHERE id_exame = :id";
        $stmt = $this->conexao->prepare($sql);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        header("Location: ../view/lista_exame.php");
        exit();
    }
    public function buscarPorId(int $id): ?Exame
    {
        $sql="select * from exame where id_exame = :id";
        $stmt= $this->conexao->prepare($sql);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchObject("Exame");
    }
    public function listar(): array
    {
        $sql="select * from exame";
        $stmt = $this->conexao->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll();
        
    }
}
?>