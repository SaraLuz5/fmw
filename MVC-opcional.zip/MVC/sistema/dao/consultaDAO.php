<?php
require_once(__DIR__ . "/../model/consulta.php");
require_once(__DIR__ . "/../model/conexao.php");
class ConsultaDAO
{
    private PDO $conexao;
    public function __construct()
    {
        $this->conexao = Conexao::conectar();
    }
    public function inserir(Consulta $obj): bool
    {
      try{
        $sql = "insert into consulta (data_hora,queixa,diagnostico,valor,situacao,id_paciente,id_medico) values(?,?,?,?,?,?,?)";
        $stmt = $this->conexao->prepare($sql);
        $stmt->bindValue(1,$obj->getData_hora());
		$stmt->bindValue(2,$obj->getQueixa());
		$stmt->bindValue(3,$obj->getDiagnostico());
		$stmt->bindValue(4,$obj->getValor());
		$stmt->bindValue(5,$obj->getSituacao());
		$stmt->bindValue(6,$obj->getId_paciente());
		$stmt->bindValue(7,$obj->getId_medico());
		
        $stmt->execute();
        header("Location: ../view/lista_consulta.php");
        exit();
        return true;
        }catch (PDOException $e){
           echo $e->getMessage();
           return false;
        }
        
    }
    public function alterar(Consulta $objeto): bool
    {
      try{
        $sql = "UPDATE consulta SET data_hora = ?,queixa = ?,diagnostico = ?,valor = ?,situacao = ?,id_paciente = ?,id_medico = ? WHERE id_consulta = ?";
        $stmt = $this->conexao->prepare($sql);
        $stmt->bindValue(1,$objeto->getData_hora());
		$stmt->bindValue(2,$objeto->getQueixa());
		$stmt->bindValue(3,$objeto->getDiagnostico());
		$stmt->bindValue(4,$objeto->getValor());
		$stmt->bindValue(5,$objeto->getSituacao());
		$stmt->bindValue(6,$objeto->getId_paciente());
		$stmt->bindValue(7,$objeto->getId_medico());
		$stmt->bindValue(8,$objeto->getId_consulta());
		
        $stmt->execute();
        header("Location: ../view/lista_consulta.php");
        exit();
        }catch (PDOException $e){
           echo $e->getMessage();
           return false;
        }
        
    }
    public function excluir(int $id)
    {
        $sql = "DELETE FROM consulta WHERE id_consulta = :id";
        $stmt = $this->conexao->prepare($sql);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        header("Location: ../view/lista_consulta.php");
        exit();
    }
    public function buscarPorId(int $id): ?Consulta
    {
        $sql="select * from consulta where id_consulta = :id";
        $stmt= $this->conexao->prepare($sql);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchObject("Consulta");
    }
    public function listar(): array
    {
        $sql="select * from consulta";
        $stmt = $this->conexao->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll();
        
    }
}
?>