DROP TABLE IF EXISTS `especialidade`;
CREATE TABLE `especialidade` (
  `id_especialidade` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(60) NOT NULL,
  `valor_consulta` decimal(8,2) NOT NULL DEFAULT '0.00',
  `ativa` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_especialidade`),
  UNIQUE KEY `nome` (`nome`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `especialidade` VALUES (1,'Clínico geral',200.00,1),(2,'Cardiologia',350.00,1),(3,'Dermatologia',300.00,1);

DROP TABLE IF EXISTS `medico`;
CREATE TABLE `medico` (
  `id_medico` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `crm` varchar(20) NOT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  `email` varchar(120) DEFAULT NULL,
  `id_especialidade` int DEFAULT NULL,
  PRIMARY KEY (`id_medico`),
  UNIQUE KEY `crm` (`crm`),
  KEY `fk_medico_especialidade` (`id_especialidade`),
  CONSTRAINT `fk_medico_especialidade` FOREIGN KEY (`id_especialidade`) REFERENCES `especialidade` (`id_especialidade`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `medico` VALUES (1,'Dr. Athos César','CRM-PR 45120','(45) 99910-1010','athos@clinica.com',1),(2,'Dra. Juliana Pereira','CRM-PR 51877','(45) 99920-2020','juliana@clinica.com',2);

DROP TABLE IF EXISTS `paciente`;
CREATE TABLE `paciente` (
  `id_paciente` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `cpf` varchar(14) NOT NULL,
  `nascimento` date DEFAULT NULL,
  `sexo` enum('F','M','outro') DEFAULT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  `convenio` enum('particular','unimed','amil','sus') NOT NULL DEFAULT 'particular',
  `alergias` text,
  `cadastrado_em` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_paciente`),
  UNIQUE KEY `cpf` (`cpf`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `paciente` VALUES (1,'Sara Luz','111.222.333-44','1988-07-23','F','(45) 99955-0001','unimed','Dipirona','2026-05-12 08:30:00'),(2,'Amanda Werner','555.666.777-88','1975-11-02','F','(45) 99955-0002','particular',NULL,'2026-06-20 16:10:00');

DROP TABLE IF EXISTS `consulta`;
CREATE TABLE `consulta` (
  `id_consulta` int NOT NULL AUTO_INCREMENT,
  `data_hora` datetime NOT NULL,
  `queixa` varchar(200) NOT NULL,
  `diagnostico` text,
  `valor` decimal(8,2) NOT NULL DEFAULT '0.00',
  `situacao` enum('agendada','realizada','cancelada','faltou') NOT NULL DEFAULT 'agendada',
  `id_paciente` int DEFAULT NULL,
  `id_medico` int DEFAULT NULL,
  PRIMARY KEY (`id_consulta`),
  KEY `fk_consulta_paciente` (`id_paciente`),
  KEY `fk_consulta_medico` (`id_medico`),
  CONSTRAINT `fk_consulta_paciente` FOREIGN KEY (`id_paciente`) REFERENCES `paciente` (`id_paciente`) ON DELETE SET NULL,
  CONSTRAINT `fk_consulta_medico` FOREIGN KEY (`id_medico`) REFERENCES `medico` (`id_medico`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `consulta` VALUES (1,'2026-10-09 10:00:00','Dor no peito ao esforço',NULL,350.00,'agendada',1,2),(2,'2026-10-02 14:00:00','Check-up anual','Exames dentro do normal',200.00,'realizada',2,1);

DROP TABLE IF EXISTS `exame`;
CREATE TABLE `exame` (
  `id_exame` int NOT NULL AUTO_INCREMENT,
  `tipo` varchar(80) NOT NULL,
  `solicitado_em` date NOT NULL,
  `resultado` text,
  `valor` decimal(8,2) DEFAULT NULL,
  `entregue` tinyint(1) NOT NULL DEFAULT '0',
  `id_consulta` int DEFAULT NULL,
  PRIMARY KEY (`id_exame`),
  KEY `fk_exame_consulta` (`id_consulta`),
  CONSTRAINT `fk_exame_consulta` FOREIGN KEY (`id_consulta`) REFERENCES `consulta` (`id_consulta`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `exame` VALUES (1,'Hemograma completo','2026-10-02','Sem alterações',45.00,1,2),(2,'Eletrocardiograma','2026-10-09',NULL,90.00,0,1);