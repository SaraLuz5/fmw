
DROP TABLE IF EXISTS `tutor`;
CREATE TABLE `tutor` (
  `id_tutor` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `cpf` varchar(14) NOT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  `email` varchar(120) DEFAULT NULL,
  PRIMARY KEY (`id_tutor`),
  UNIQUE KEY `cpf` (`cpf`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tutor` VALUES (1,'Sara Luz','123.456.789-00','(45) 99911-2233','sara@gmail.com'),(2,'Amanda Werner','987.654.321-00','(45) 99888-4455','amanda@gmail.com');


DROP TABLE IF EXISTS `veterinario`;
CREATE TABLE `veterinario` (
  `id_veterinario` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `crmv` varchar(20) NOT NULL,
  `especialidade` varchar(60) DEFAULT NULL,
  `ativo` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_veterinario`),
  UNIQUE KEY `crmv` (`crmv`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `veterinario` VALUES (1,'Dra. Juliana ','PR-10234','Clínica geral',1),(2,'Dr. Athos','PR-20987','Dermatologia',1);

DROP TABLE IF EXISTS `animal`;
CREATE TABLE `animal` (
  `id_animal` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(60) NOT NULL,
  `especie` enum('cachorro','gato','ave','roedor','outro') NOT NULL DEFAULT 'cachorro',
  `raca` varchar(60) DEFAULT NULL,
  `nascimento` date DEFAULT NULL,
  `peso_kg` decimal(5,2) DEFAULT NULL,
  `observacoes` text,
  `id_tutor` int DEFAULT NULL,
  PRIMARY KEY (`id_animal`),
  KEY `fk_animal_tutor` (`id_tutor`),
  CONSTRAINT `fk_animal_tutor` FOREIGN KEY (`id_tutor`) REFERENCES `tutor` (`id_tutor`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `animal` VALUES (1,'Meio Dia','cachorro','Pr. Australiano','2021-05-19',32.50,'Alérgico a frango',1),(2,'Pituca','cachorro','Lhasa','2023-01-20',4.10,'Castrada',2);

DROP TABLE IF EXISTS `consulta`;
CREATE TABLE `consulta` (
  `id_consulta` int NOT NULL AUTO_INCREMENT,
  `data_hora` datetime NOT NULL,
  `motivo` varchar(150) NOT NULL,
  `diagnostico` text,
  `valor` decimal(8,2) NOT NULL DEFAULT '0.00',
  `situacao` enum('agendada','realizada','cancelada') NOT NULL DEFAULT 'agendada',
  `id_animal` int DEFAULT NULL,
  `id_veterinario` int DEFAULT NULL,
  PRIMARY KEY (`id_consulta`),
  KEY `fk_consulta_animal` (`id_animal`),
  KEY `fk_consulta_veterinario` (`id_veterinario`),
  CONSTRAINT `fk_consulta_animal` FOREIGN KEY (`id_animal`) REFERENCES `animal` (`id_animal`) ON DELETE SET NULL,
  CONSTRAINT `fk_consulta_veterinario` FOREIGN KEY (`id_veterinario`) REFERENCES `veterinario` (`id_veterinario`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `consulta` VALUES (1,'2026-10-08 09:00:00','Vacina anual',NULL,120.00,'agendada',1,1),(2,'2026-10-01 15:30:00','Coceira constante','Dermatite alérgica',180.00,'realizada',2,2);